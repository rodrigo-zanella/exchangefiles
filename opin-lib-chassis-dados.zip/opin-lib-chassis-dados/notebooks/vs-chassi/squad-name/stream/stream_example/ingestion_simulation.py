import time

time.sleep(20)
raise NameError('Erro')
from src.make_believe import make_believe
def teste_pass():
    assert make_believe()

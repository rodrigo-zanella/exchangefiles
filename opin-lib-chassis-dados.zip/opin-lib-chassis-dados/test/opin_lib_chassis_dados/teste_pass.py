def teste_pass():
    assert True

from enum import Enum


class EnumLinksSilverFields(Enum):
    IDTFD_FILME = "IDTFD_MRCAO"
    IDTFD_IMDB = "IDTFD_MRCAO"
    IDTFD_TMDB = "IDTFD_MRCAO"
    IDTFD_DBASE_OPER = "IDTFD_DBASE_OPER"

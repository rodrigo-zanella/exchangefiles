from enum import Enum


class EnumRatingsSilverFields(Enum):
    IDTFD_USUAR = "IDTFD_USUAR"
    IDTFD_FILME = "IDTFD_FILME"
    AVALC = "AVALC"
    DATA_HORA = "DATA_HORA"
    IDTFD_DBASE_OPER = "IDTFD_DBASE_OPER"

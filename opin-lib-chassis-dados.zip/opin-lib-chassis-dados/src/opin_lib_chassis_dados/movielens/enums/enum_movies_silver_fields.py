from enum import Enum


class EnumMoviesSilverFields(Enum):
    IDTFD_FILME = "IDTFD_FILME"
    DESCR_TITLO = "DESCR_TITLO"
    DESCR_GNERO = "DESCR_GNERO"
    IDTFD_DBASE_OPER = "IDTFD_DBASE_OPER"

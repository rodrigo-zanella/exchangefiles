from enum import Enum


class EnumGenomeTagsBronzeFields(Enum):
    TAG_ID = "tagId"
    TAG = "tag"
    DATABASE_OPERATION_INDICATOR = "dbaseOperationIndicator"

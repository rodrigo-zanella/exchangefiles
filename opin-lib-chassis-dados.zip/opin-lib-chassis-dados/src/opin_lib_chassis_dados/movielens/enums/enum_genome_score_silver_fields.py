from enum import Enum

class EnumGenomeScoresSilverFields(Enum):
    IDTFD_FILME = "IDTFD_FILME"
    IDTFD_MRCAO = "IDTFD_MRCAO"
    RELEV = "RELEV"
    IDTFD_DBASE_OPER = "IDTFD_DBASE_OPER"

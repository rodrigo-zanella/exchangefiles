from enum import Enum


class EnumGenomeTagsSilverFields(Enum):
    IDTFD_MRCAO = "IDTFD_MRCAO"
    DESCR_MRCAO = "DESCR_MRCAO"
    IDTFD_DBASE_OPER = "IDTFD_DBASE_OPER"

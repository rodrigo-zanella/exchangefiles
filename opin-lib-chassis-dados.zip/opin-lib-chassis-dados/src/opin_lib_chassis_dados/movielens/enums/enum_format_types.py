from enum import Enum


class EnumFormatTypes(Enum):
    AVRO = "avro"
    CSV = "csv"
    DELTA = "delta"
    JSON = "json"

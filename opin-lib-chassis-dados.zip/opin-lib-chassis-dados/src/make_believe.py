def make_believe():
    return True
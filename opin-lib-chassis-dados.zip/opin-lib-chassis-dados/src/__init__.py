from platform import python_version

__python_version__ = python_version()
__name__ = 'opin_lib_chassis_dados'
__title__ = 'Projec\'t Title. Example: Sample source code'
__description__ = 'Project\'s Description'
__version__ = '1.0.0'
__author__ = 'Author name'
__python_requires__ = '>=3.8.5'
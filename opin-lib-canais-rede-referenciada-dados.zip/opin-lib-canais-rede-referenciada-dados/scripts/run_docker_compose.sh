#!/usr/bin/env bash

pipeline=$2
if [ $pipeline == "dev" ];
then
  docker_compose_dir=mongodb
elif [ $pipeline == "test" ];
then
  docker_compose_dir=sonar
fi

case "$1" in
  --build)
    #sudo docker-compose -f docker/${docker_compose_dir}/docker-compose.yml up -d --build
    echo docker/${docker_compose_dir}/docker-compose.yml
    shift
    ;;
  --start)
    sudo docker-compose -f docker/${docker_compose_dir}/docker-compose.yml up -d
    shift
    ;;
  --stop-all)
    sudo docker stop $(sudo docker ps -q)
    shift
    ;;
  --info)
    sudo docker ps -f name=mongodb-opin -f name=mongo-express-opin
    shift
    ;;
  *) echo "Option $1 not recognized" ;;
esac
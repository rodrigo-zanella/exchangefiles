#!/usr/bin/env bash

export PYTHONPATH=./src/

if [ -z $1 ]; then
  # Runs all unit test case.
  pytest
else
  # Runs specific unit test case.
  pytest $1
fi

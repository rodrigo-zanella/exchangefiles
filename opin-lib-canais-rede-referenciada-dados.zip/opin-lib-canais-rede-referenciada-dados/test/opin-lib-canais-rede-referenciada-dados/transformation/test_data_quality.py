import pytest
from pyspark.sql import Row
import pyspark.sql.types as T
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_data_quality import EnumDataQuality
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_data import EnumTestData
from opin_lib_canais_rede_referenciada_dados.transformation.rede_referenciada import mandatory_field_validator, \
    field_length_validator


@pytest.mark.usefixtures("spark_session")
def test_mandatory_field_validator(spark_session):
    """ Test that all mandatory fields which contains null values are listed on field camposObrigatoriosNaoPreenchidos """

    expected_rows = Row(EnumTestData.MARCA_NULO.value,
                        EnumTestData.NOME_SOCIEDADE_NULO.value,
                        EnumTestData.CNPJ_SOCIEDADE.value,
                        EnumTestData.NOME_REDE_REFERENCIADA.value,
                        EnumTestData.CNPJ_REDE_REFERENCIADA.value,
                        EnumTestData.NOME_PRODUTO.value,
                        EnumTestData.CODIGO_PRODUTO.value,
                        EnumTestData.ENDERECO.value,
                        EnumTestData.BAIRRO.value,
                        EnumTestData.MUNICIPIO.value,
                        EnumTestData.UF.value,
                        EnumTestData.COD_IBGE.value,
                        EnumTestData.CEP.value,
                        EnumTestData.TIPO_SERVICO.value,
                        EnumTestData.NOME_SERVICOS_PRESTADOS.value,
                        EnumTestData.DESCRICAO_TIPO_SERVICOS.value,
                        f"{EnumBronzeFields.MARCA.value},{EnumBronzeFields.NOME_SOCIEDADE.value}")

    expected_schema = T.StructType([
        T.StructField(EnumBronzeFields.MARCA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.ENDERECO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.BAIRRO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.MUNICIPIO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.UF.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COD_IBGE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CEP.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_SERVICO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DESCRICAO_TIPO_SERVICOS.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value, T.StringType(), True)
    ])

    expected = spark_session.createDataFrame([expected_rows], schema=expected_schema)

    mock_row = Row(EnumTestData.MARCA_NULO.value,
                   EnumTestData.NOME_SOCIEDADE_NULO.value,
                   EnumTestData.CNPJ_SOCIEDADE.value,
                   EnumTestData.NOME_REDE_REFERENCIADA.value,
                   EnumTestData.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestData.NOME_PRODUTO.value,
                   EnumTestData.CODIGO_PRODUTO.value,
                   EnumTestData.ENDERECO.value,
                   EnumTestData.BAIRRO.value,
                   EnumTestData.MUNICIPIO.value,
                   EnumTestData.UF.value,
                   EnumTestData.COD_IBGE.value,
                   EnumTestData.CEP.value,
                   EnumTestData.TIPO_SERVICO.value,
                   EnumTestData.NOME_SERVICOS_PRESTADOS.value,
                   EnumTestData.DESCRICAO_TIPO_SERVICOS.value,
                   )

    mock_schema = T.StructType([
        T.StructField(EnumBronzeFields.MARCA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.ENDERECO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.BAIRRO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.MUNICIPIO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.UF.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COD_IBGE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CEP.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_SERVICO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DESCRICAO_TIPO_SERVICOS.value, T.StringType(), True)
    ])

    mock = spark_session.createDataFrame([mock_row], schema=mock_schema)

    # Act #
    result_spark = mandatory_field_validator(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_field_length_validator(spark_session):
    """ Test that all fields which contains length above the limit are listed on field tamanhoCampoInvalido """

    expected_rows = Row(EnumTestData.MARCA.value,
                        EnumTestData.NOME_SOCIEDADE.value,
                        EnumTestData.CNPJ_SOCIEDADE_SEM_MASCARA.value,
                        EnumTestData.NOME_REDE_REFERENCIADA.value,
                        EnumTestData.CNPJ_REDE_REFERENCIADA_SEM_MASCARA.value,
                        EnumTestData.NOME_PRODUTO.value,
                        EnumTestData.CODIGO_PRODUTO.value,
                        EnumTestData.NOME_COBERTURA.value,
                        EnumTestData.ENDERECO.value,
                        EnumTestData.COMPLEMENTO_WRONG_LENGTH.value,
                        EnumTestData.BAIRRO.value,
                        EnumTestData.MUNICIPIO.value,
                        EnumTestData.UF.value,
                        EnumTestData.CEP_WITH_WRONG_LENGTH.value,
                        EnumTestData.PAIS.value,
                        EnumTestData.COD_PAIS.value,
                        EnumTestData.LATITUDE.value,
                        EnumTestData.LONGITUDE.value,
                        EnumTestData.TIPO_TELEFONE.value,
                        EnumTestData.DDI.value,
                        EnumTestData.DDD.value,
                        EnumTestData.NUM_TELEFONE.value,
                        EnumTestData.TIPO_SERVICO.value,
                        EnumTestData.TIPO_SERVICO_OUTROS.value,
                        EnumTestData.COD_IBGE.value,
                        EnumTestData.HORARIO_ABERTURA.value,
                        EnumTestData.HORARIO_ENCERRAMENTO.value,
                        EnumTestData.NOME_SERVICO_UNICO.value,
                        EnumTestData.DESCRICAO_TIPO_SERVICOS.value,
                        f"{EnumBronzeFields.COMPLEMENTO.value},{EnumBronzeFields.CEP.value}")

    expected_schema = T.StructType([
        T.StructField(EnumBronzeFields.MARCA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_COBERTURA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.ENDERECO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COMPLEMENTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.BAIRRO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.MUNICIPIO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.UF.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CEP.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.PAIS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COD_PAIS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.LATITUDE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.LONGITUDE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_TELEFONE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DDI.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DDD.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NUM_TELEFONE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_SERVICO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_SERVICO_OUTROS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COD_IBGE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.HORARIO_ABERTURA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.HORARIO_ENCERRAMENTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DESCRICAO_TIPO_SERVICOS.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value, T.StringType(), True)
    ])

    expected = spark_session.createDataFrame([expected_rows], schema=expected_schema)

    mock_row = Row(EnumTestData.MARCA.value,
                   EnumTestData.NOME_SOCIEDADE.value,
                   EnumTestData.CNPJ_SOCIEDADE_SEM_MASCARA.value,
                   EnumTestData.NOME_REDE_REFERENCIADA.value,
                   EnumTestData.CNPJ_REDE_REFERENCIADA_SEM_MASCARA.value,
                   EnumTestData.NOME_PRODUTO.value,
                   EnumTestData.CODIGO_PRODUTO.value,
                   EnumTestData.NOME_COBERTURA.value,
                   EnumTestData.ENDERECO.value,
                   EnumTestData.COMPLEMENTO_WRONG_LENGTH.value,
                   EnumTestData.BAIRRO.value,
                   EnumTestData.MUNICIPIO.value,
                   EnumTestData.UF.value,
                   EnumTestData.CEP_WITH_WRONG_LENGTH.value,
                   EnumTestData.PAIS.value,
                   EnumTestData.COD_PAIS.value,
                   EnumTestData.LATITUDE.value,
                   EnumTestData.LONGITUDE.value,
                   EnumTestData.TIPO_TELEFONE.value,
                   EnumTestData.DDI.value,
                   EnumTestData.DDD.value,
                   EnumTestData.NUM_TELEFONE.value,
                   EnumTestData.TIPO_SERVICO.value,
                   EnumTestData.TIPO_SERVICO_OUTROS.value,
                   EnumTestData.COD_IBGE.value,
                   EnumTestData.HORARIO_ABERTURA.value,
                   EnumTestData.HORARIO_ENCERRAMENTO.value,
                   EnumTestData.NOME_SERVICO_UNICO.value,
                   EnumTestData.DESCRICAO_TIPO_SERVICOS.value,
                   )

    mock_schema = T.StructType([
        T.StructField(EnumBronzeFields.MARCA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_SOCIEDADE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_COBERTURA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.ENDERECO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COMPLEMENTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.BAIRRO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.MUNICIPIO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.UF.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.CEP.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.PAIS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COD_PAIS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.LATITUDE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.LONGITUDE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_TELEFONE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DDI.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DDD.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NUM_TELEFONE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_SERVICO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.TIPO_SERVICO_OUTROS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.COD_IBGE.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.HORARIO_ABERTURA.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.HORARIO_ENCERRAMENTO.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value, T.StringType(), True),
        T.StructField(EnumBronzeFields.DESCRICAO_TIPO_SERVICOS.value, T.StringType(), True)
    ])

    mock = spark_session.createDataFrame([mock_row], schema=mock_schema)

    # Act #
    result_spark = field_length_validator(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

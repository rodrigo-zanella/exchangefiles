import pytest
from pyspark.sql import Row
import pyspark.sql.types as T
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_data import EnumTestData
from opin_lib_canais_rede_referenciada_dados.transformation.rede_referenciada import \
    remove_final_delimiter_multivalues_fields, remove_numerical_masks, trim_fields, treat_null_boolean_fields, \
    treat_null_values


@pytest.mark.usefixtures("spark_session")
def test_remove_final_delimiter_with_error(spark_session):
    """ Test that the final delimiter from multivalues fields are removed if there isn't a number after it """
    expected_row = Row(EnumTestData.NOME_SERVICO_WITHOUT_FINAL_DELIMITER.value)
    expected_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.NOME_SERVICO_FINAL_DELIMITER.value)
    mock_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    columns_list = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    delimiter = ";"
    result_spark = remove_final_delimiter_multivalues_fields(mock, columns_list, delimiter)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_remove_final_delimiter_without_error(spark_session):
    """ Test that the function will not affect the data if the delimiter is not present at the final of value """

    expected_row = Row(EnumTestData.NOME_SERVICO_WITHOUT_FINAL_DELIMITER.value)
    expected_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.NOME_SERVICO_WITHOUT_FINAL_DELIMITER.value)
    mock_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    columns_list = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    delimiter = ";"
    result_spark = remove_final_delimiter_multivalues_fields(mock, columns_list, delimiter)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_remove_numerical_masks(spark_session):
    """ Test that the function remove all special characters from numerical values """

    expected_row = Row(EnumTestData.CNPJ_REDE_REFERENCIADA_SEM_MASCARA.value)
    expected_columns = [EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value]
    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.CNPJ_REDE_REFERENCIADA.value)
    mock_columns = [EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value]
    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    columns_list = [EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value]
    result_spark = remove_numerical_masks(mock, columns_list)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_trim_fields(spark_session):
    """ Test that the function remove all left and right spaces in values """

    expected_row = Row(EnumTestData.BAIRRO.value)
    expected_columns = [EnumBronzeFields.BAIRRO.value]
    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.BAIRRO_COM_ESPACOS.value)
    mock_columns = [EnumBronzeFields.BAIRRO.value]
    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = trim_fields(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_treat_null_boolean_fields(spark_session):
    """ Test that the function change empty values with false boolean value """

    expected_row = Row(EnumTestData.INDICADOR_RESTRICAO_ACESSO_ESPERADO.value)
    expected_columns = [EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value]
    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.INDICADOR_RESTRICAO_ACESSO_NULO.value)
    mock_schema = T.StructType([T.StructField(EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value, T.NullType(), True)])
    mock = spark_session.createDataFrame([mock_row], mock_schema)

    # Act #
    result_spark = treat_null_boolean_fields(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_treat_non_null_boolean_fields(spark_session):
    """ Test that the function don't change nom empty values with false boolean value """

    expected_row = Row(EnumTestData.INDICADOR_RESTRICAO_ACESSO_ESPERADO_NAO_NULO.value)
    expected_columns = [EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value]
    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.INDICADOR_RESTRICAO_ACESSO_NAO_NULO.value)
    mock_columns = [EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value]
    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = treat_null_boolean_fields(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

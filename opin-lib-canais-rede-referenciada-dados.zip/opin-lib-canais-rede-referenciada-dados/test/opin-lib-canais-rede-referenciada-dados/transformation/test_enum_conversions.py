import pytest
from pyspark.sql import Row
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_data import EnumTestData
from opin_lib_canais_rede_referenciada_dados.transformation.rede_referenciada import get_phone_type_from_enum, \
    get_service_type_from_enum, get_service_name_from_enum, get_week_day_from_enum, get_country_name_from_enum, \
    get_country_sub_division_name_from_enum


@pytest.mark.usefixtures("spark_session")
def test_get_phone_type_from_enum(spark_session):
    """ Test that the function convert phone types based on Enum """

    expected_row = Row(EnumTestData.TIPO_TELEFONE_CONVERTIDO.value)

    expected_columns = [EnumBronzeFields.TIPO_TELEFONE.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.TIPO_TELEFONE_ORIGINAL.value)

    mock_columns = [EnumBronzeFields.TIPO_TELEFONE.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_phone_type_from_enum(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_service_type_from_enum(spark_session):
    """ Test that the function convert service types based on Enum """

    expected_row = Row(EnumTestData.TIPO_SERVICO_CONVERTIDO.value)

    expected_columns = [EnumBronzeFields.TIPO_SERVICO.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.TIPO_SERVICO_ORIGINAL.value)

    mock_columns = [EnumBronzeFields.TIPO_SERVICO.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_service_type_from_enum(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_service_name_from_enum(spark_session):
    """ Test that the function convert service types based on Enum """

    expected_row = Row(EnumTestData.NOME_SERVICOS_PRESTADOS_CONVERTIDO.value)

    expected_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.NOME_SERVICOS_PRESTADOS_ORIGINAL.value)

    mock_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_service_name_from_enum(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_week_day_name_from_enum(spark_session):
    """ Test that the function convert service types based on Enum """

    expected_row = Row(EnumTestData.DIAS_FUNCIONAMENTO_CONVERTIDO.value)

    expected_columns = [EnumBronzeFields.DIAS_FUNCIONAMENTO.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.DIAS_FUNCIONAMENTO_ORIGINAL.value)

    mock_columns = [EnumBronzeFields.DIAS_FUNCIONAMENTO.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_week_day_from_enum(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_country_name_from_enum(spark_session):
    """ Test that the function convert service types based on Enum """

    expected_row = Row(EnumTestData.PAIS_CONVERTIDO.value)

    expected_columns = [EnumBronzeFields.PAIS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.PAIS_ORIGINAL.value)

    mock_columns = [EnumBronzeFields.PAIS.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_country_name_from_enum(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_country_sub_division_name_from_enum(spark_session):
    """ Test that the function convert service types based on Enum """

    expected_row = Row(EnumTestData.UF_CONVERTIDO.value)

    expected_columns = [EnumBronzeFields.UF.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.UF_ORIGINAL.value)

    mock_columns = [EnumBronzeFields.UF.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_country_sub_division_name_from_enum(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

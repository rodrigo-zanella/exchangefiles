from pyspark.sql import Row
import pyspark.sql.types as T
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_data_quality import EnumDataQuality
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_data import EnumTestData
from opin_lib_canais_rede_referenciada_dados.transformation.rede_referenciada import filter_invalid_data, \
    filter_valid_data, filter_deleted_records


def test_filter_invalid_data(spark_session):
    """ Test that the function filter invalid data from dataframe """

    expected_rows = [
        Row(EnumTestData.CODIGO_PRODUTO.value, "",
            f"{EnumBronzeFields.MARCA.value},{EnumBronzeFields.NOME_SOCIEDADE.value}", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}", "", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            "", "", f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}"),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            f"{EnumBronzeFields.MARCA.value},{EnumBronzeFields.NOME_SOCIEDADE.value}",
            f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}", ""),
    ]

    expected_schema = T.StructType([
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value, T.StringType(), True)
    ])

    expected = spark_session.createDataFrame(expected_rows, schema=expected_schema)

    mock_row = [
        Row(EnumTestData.CODIGO_PRODUTO.value, "",
            f"{EnumBronzeFields.MARCA.value},{EnumBronzeFields.NOME_SOCIEDADE.value}", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}", "", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            "", "", f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}"),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            f"{EnumBronzeFields.MARCA.value},{EnumBronzeFields.NOME_SOCIEDADE.value}",
            f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value, "", "", "")
    ]

    mock_schema = T.StructType([
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value, T.StringType(), True)
    ])

    mock = spark_session.createDataFrame(mock_row, schema=mock_schema)

    # Act #
    result_spark = filter_invalid_data(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


def test_filter_valid_data(spark_session):
    """ Test that fields contains invalid data are excluded from dataframe """

    expected_rows = [Row(EnumTestData.CODIGO_PRODUTO.value)]

    expected_schema = T.StructType([
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True)
    ])

    expected = spark_session.createDataFrame(expected_rows, schema=expected_schema)

    mock_row = [
        Row(EnumTestData.CODIGO_PRODUTO.value, "",
            f"{EnumBronzeFields.MARCA.value},{EnumBronzeFields.NOME_SOCIEDADE.value}", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}", "", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            "", "", f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}"),
        Row(EnumTestData.CODIGO_PRODUTO.value,
            f"{EnumBronzeFields.MARCA.value},{EnumBronzeFields.NOME_SOCIEDADE.value}",
            f"{EnumBronzeFields.CNPJ_SOCIEDADE.value},{EnumBronzeFields.NOME_REDE_REFERENCIADA.value}", ""),
        Row(EnumTestData.CODIGO_PRODUTO.value, "", "", "")
    ]

    mock_schema = T.StructType([
        T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value, T.StringType(), True),
        T.StructField(EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value, T.StringType(), True)
    ])

    mock = spark_session.createDataFrame(mock_row, schema=mock_schema)

    # Act #
    result_spark = filter_valid_data(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


def test_filter_deleted_records(spark_session):
    """ Test that the function get the ROW_ID from deleted rows """

    expected_rows = [Row(EnumTestData.ROW_ID_CASE2.value)]
    expected_columns = [EnumSilverFields.ROW_ID.value]
    expected = spark_session.createDataFrame(expected_rows, schema=expected_columns)

    mock_rows_old = [Row(EnumTestData.MARCA.value,
                         EnumTestData.NOME_SOCIEDADE.value,
                         EnumTestData.CNPJ_SOCIEDADE.value,
                         EnumTestData.NOME_REDE_REFERENCIADA.value,
                         EnumTestData.CNPJ_REDE_REFERENCIADA_CASE1.value),
                     Row(EnumTestData.MARCA.value,
                         EnumTestData.NOME_SOCIEDADE.value,
                         EnumTestData.CNPJ_SOCIEDADE.value,
                         EnumTestData.NOME_REDE_REFERENCIADA.value,
                         EnumTestData.CNPJ_REDE_REFERENCIADA_CASE2.value)]

    mock_rows_new = [Row(EnumTestData.MARCA.value,
                         EnumTestData.NOME_SOCIEDADE.value,
                         EnumTestData.CNPJ_SOCIEDADE.value,
                         EnumTestData.NOME_REDE_REFERENCIADA.value,
                         EnumTestData.CNPJ_REDE_REFERENCIADA_CASE1.value),
                     Row(EnumTestData.MARCA.value,
                         EnumTestData.NOME_SOCIEDADE.value,
                         EnumTestData.CNPJ_SOCIEDADE.value,
                         EnumTestData.NOME_REDE_REFERENCIADA.value,
                         EnumTestData.CNPJ_REDE_REFERENCIADA_CASE1.value)]

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value]

    mock_old = spark_session.createDataFrame(mock_rows_old, schema=mock_columns)
    mock_new = spark_session.createDataFrame(mock_rows_new, schema=mock_columns)
    # Act #
    result_spark = filter_deleted_records(spark_session, mock_new, mock_old)
    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

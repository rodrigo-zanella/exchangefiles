import pytest
from pyspark.sql import Row
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_data import EnumTestData
from opin_lib_canais_rede_referenciada_dados.transformation.rede_referenciada import create_row_id_field, \
    rename_bronze_to_silver_columns, explode_multivalues_fields, \
    remove_accents_and_special_characters_to_referenced_name, remove_accents_and_special_characters_from_fields


@pytest.mark.usefixtures("spark_session")
def test_create_row_id_field(spark_session):
    """ Test that the function create a row_id field """

    expected_row = Row(EnumTestData.MARCA.value,
                       EnumTestData.NOME_SOCIEDADE.value,
                       EnumTestData.CNPJ_SOCIEDADE.value,
                       EnumTestData.NOME_REDE_REFERENCIADA.value,
                       EnumTestData.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestData.ROW_ID_CASE1.value)

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.ROW_ID.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.MARCA.value,
                   EnumTestData.NOME_SOCIEDADE.value,
                   EnumTestData.CNPJ_SOCIEDADE.value,
                   EnumTestData.NOME_REDE_REFERENCIADA.value,
                   EnumTestData.CNPJ_REDE_REFERENCIADA.value, )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = create_row_id_field(mock)
    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


# rename_bronze_to_silver_columns
def test_rename_bronze_to_silver_columns(spark_session):
    """ Test that columns are renamed from bronze names to silver names """

    expected_row = Row(EnumTestData.MARCA.value,
                       EnumTestData.NOME_SOCIEDADE.value,
                       EnumTestData.CNPJ_SOCIEDADE.value,
                       EnumTestData.NOME_REDE_REFERENCIADA.value,
                       EnumTestData.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestData.NOME_PRODUTO.value,
                       EnumTestData.CODIGO_PRODUTO.value,
                       EnumTestData.NOME_COBERTURA.value,
                       EnumTestData.ENDERECO.value,
                       EnumTestData.COMPLEMENTO.value,
                       EnumTestData.BAIRRO.value,
                       EnumTestData.MUNICIPIO.value,
                       EnumTestData.UF.value,
                       EnumTestData.COD_IBGE.value,
                       EnumTestData.CEP.value,
                       EnumTestData.PAIS.value,
                       EnumTestData.COD_PAIS.value,
                       EnumTestData.LATITUDE.value,
                       EnumTestData.LONGITUDE.value,
                       EnumTestData.HORARIO_ABERTURA.value,
                       EnumTestData.HORARIO_ENCERRAMENTO.value,
                       EnumTestData.DIAS_FUNCIONAMENTO.value,
                       EnumTestData.INDICADOR_RESTRICAO_ACESSO.value,
                       EnumTestData.TIPO_TELEFONE.value,
                       EnumTestData.DDI.value,
                       EnumTestData.DDD.value,
                       EnumTestData.NUM_TELEFONE.value,
                       EnumTestData.TIPO_SERVICO.value,
                       EnumTestData.TIPO_SERVICO_OUTROS.value,
                       EnumTestData.NOME_SERVICOS_PRESTADOS.value)

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.NOME_PRODUTO.value,
                        EnumSilverFields.CODIGO_PRODUTO.value,
                        EnumSilverFields.NOME_COBERTURA.value,
                        EnumSilverFields.ENDERECO.value,
                        EnumSilverFields.COMPLEMENTO.value,
                        EnumSilverFields.BAIRRO.value,
                        EnumSilverFields.MUNICIPIO.value,
                        EnumSilverFields.UF.value,
                        EnumSilverFields.COD_IBGE.value,
                        EnumSilverFields.CEP.value,
                        EnumSilverFields.PAIS.value,
                        EnumSilverFields.COD_PAIS.value,
                        EnumSilverFields.LATITUDE.value,
                        EnumSilverFields.LONGITUDE.value,
                        EnumSilverFields.HORARIO_ABERTURA.value,
                        EnumSilverFields.HORARIO_ENCERRAMENTO.value,
                        EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                        EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                        EnumSilverFields.TIPO_TELEFONE.value,
                        EnumSilverFields.DDI.value,
                        EnumSilverFields.DDD.value,
                        EnumSilverFields.NUM_TELEFONE.value,
                        EnumSilverFields.TIPO_SERVICO.value,
                        EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                        EnumSilverFields.NOME_SERVICOS_PRESTADOS.value,
                        ]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestData.MARCA.value,
                   EnumTestData.NOME_SOCIEDADE.value,
                   EnumTestData.CNPJ_SOCIEDADE.value,
                   EnumTestData.NOME_REDE_REFERENCIADA.value,
                   EnumTestData.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestData.NOME_PRODUTO.value,
                   EnumTestData.CODIGO_PRODUTO.value,
                   EnumTestData.NOME_COBERTURA.value,
                   EnumTestData.ENDERECO.value,
                   EnumTestData.COMPLEMENTO.value,
                   EnumTestData.BAIRRO.value,
                   EnumTestData.MUNICIPIO.value,
                   EnumTestData.UF.value,
                   EnumTestData.COD_IBGE.value,
                   EnumTestData.CEP.value,
                   EnumTestData.PAIS.value,
                   EnumTestData.COD_PAIS.value,
                   EnumTestData.LATITUDE.value,
                   EnumTestData.LONGITUDE.value,
                   EnumTestData.HORARIO_ABERTURA.value,
                   EnumTestData.HORARIO_ENCERRAMENTO.value,
                   EnumTestData.DIAS_FUNCIONAMENTO.value,
                   EnumTestData.INDICADOR_RESTRICAO_ACESSO.value,
                   EnumTestData.TIPO_TELEFONE.value,
                   EnumTestData.DDI.value,
                   EnumTestData.DDD.value,
                   EnumTestData.NUM_TELEFONE.value,
                   EnumTestData.TIPO_SERVICO.value,
                   EnumTestData.TIPO_SERVICO_OUTROS.value,
                   EnumTestData.NOME_SERVICOS_PRESTADOS.value
                   )

    mock_columns = [EnumBronzeFields.MARCA.value,
                    EnumBronzeFields.NOME_SOCIEDADE.value,
                    EnumBronzeFields.CNPJ_SOCIEDADE.value,
                    EnumBronzeFields.NOME_REDE_REFERENCIADA.value,
                    EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumBronzeFields.NOME_PRODUTO.value,
                    EnumBronzeFields.CODIGO_PRODUTO.value,
                    EnumBronzeFields.NOME_COBERTURA.value,
                    EnumBronzeFields.ENDERECO.value,
                    EnumBronzeFields.COMPLEMENTO.value,
                    EnumBronzeFields.BAIRRO.value,
                    EnumBronzeFields.MUNICIPIO.value,
                    EnumBronzeFields.UF.value,
                    EnumBronzeFields.COD_IBGE.value,
                    EnumBronzeFields.CEP.value,
                    EnumBronzeFields.PAIS.value,
                    EnumBronzeFields.COD_PAIS.value,
                    EnumBronzeFields.LATITUDE.value,
                    EnumBronzeFields.LONGITUDE.value,
                    EnumBronzeFields.HORARIO_ABERTURA.value,
                    EnumBronzeFields.HORARIO_ENCERRAMENTO.value,
                    EnumBronzeFields.DIAS_FUNCIONAMENTO.value,
                    EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value,
                    EnumBronzeFields.TIPO_TELEFONE.value,
                    EnumBronzeFields.DDI.value,
                    EnumBronzeFields.DDD.value,
                    EnumBronzeFields.NUM_TELEFONE.value,
                    EnumBronzeFields.TIPO_SERVICO.value,
                    EnumBronzeFields.TIPO_SERVICO_OUTROS.value,
                    EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value
                    ]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = rename_bronze_to_silver_columns(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_explode_multivalues_fields(spark_session):
    """ Test that the function explode multivalues fields to rows """

    expected_rows = [Row(EnumTestData.NOME_SERVICO_EXPLODED_ROW1.value),
                     Row(EnumTestData.NOME_SERVICO_EXPLODED_ROW2.value)]

    expected_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    expected = spark_session.createDataFrame(expected_rows, expected_columns)

    mock_row = Row(EnumTestData.NOME_SERVICO_TO_EXPLODE.value)
    mock_columns = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    columns_list = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]
    delimiter = ";"
    result_spark = explode_multivalues_fields(mock, columns_list, delimiter)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_remove_accents_and_special_characters_to_referenced_name(spark_session):
    """ Test that the function explode multivalues fields to rows """

    expected_rows = Row(EnumTestData.NOME_REDE_REFERENCIADA_CONVERTIDO.value)

    expected_columns = [EnumBronzeFields.NOME_REDE_REFERENCIADA.value]
    expected = spark_session.createDataFrame([expected_rows], expected_columns)

    mock_row = Row(EnumTestData.NOME_REDE_REFERENCIADA_ORIGINAL.value)
    mock_columns = [EnumBronzeFields.NOME_REDE_REFERENCIADA.value]
    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = remove_accents_and_special_characters_to_referenced_name(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_remove_accents_and_special_characters_from_fields(spark_session):
    """ Test that the function explode multivalues fields to rows """

    expected_rows = Row(EnumTestData.TIPO_SERVICO_ORIGINAL.value,
                        EnumTestData.DIAS_FUNCIONAMENTO_ORIGINAL.value,
                        EnumTestData.PAIS_ORIGINAL.value,
                        EnumTestData.UF_ORIGINAL.value,
                        EnumTestData.NOME_SERVICOS_PRESTADOS_TREAT.value)

    columns = [EnumBronzeFields.TIPO_SERVICO.value,
               EnumBronzeFields.DIAS_FUNCIONAMENTO.value,
               EnumBronzeFields.PAIS.value,
               EnumBronzeFields.UF.value,
               EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value]

    expected = spark_session.createDataFrame([expected_rows], columns)

    mock_row = Row(EnumTestData.TIPO_SERVICO_ENTRADA.value,
                   EnumTestData.DIAS_FUNCIONAMENTO_ENTRADA.value,
                   EnumTestData.PAIS_ENTRADA.value,
                   EnumTestData.UF_ENTRADA.value,
                   EnumTestData.NOME_SERVICOS_PRESTADOS_UNICO.value)

    mock = spark_session.createDataFrame([mock_row], columns)

    # Act #
    result_spark = remove_accents_and_special_characters_from_fields(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

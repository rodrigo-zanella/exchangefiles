import pytest
from pyspark.sql import Row
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_db_fields import EnumDbFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_json import EnumTestJson
from opin_lib_canais_rede_referenciada_dados.load.rede_referenciada import get_postal_address_as_json, \
    get_postal_address, get_postal_address_list


@pytest.mark.usefixtures("spark_session")
def test_get_postal_address_as_json(spark_session):
    """ Test that the function get the postal addresses fields in JSON format """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.ENDERECO.value,
                       EnumTestJson.COMPLEMENTO.value,
                       EnumTestJson.BAIRRO.value,
                       EnumTestJson.MUNICIPIO.value,
                       EnumTestJson.UF.value,
                       EnumTestJson.CEP.value,
                       EnumTestJson.PAIS.value,
                       EnumTestJson.COD_PAIS.value,
                       EnumTestJson.LATITUDE.value,
                       EnumTestJson.LONGITUDE.value,
                       EnumTestJson.COD_IBGE.value,
                       '{"address": "Alameda Araguaia, 2104 – Alphaville – Barueri-SP 23 e 24º. Andar - CEP: 06455-000", '
                       '"additionalInfo": "23 e 24º. Andar", '
                       '"districtName": "Alphaville", '
                       '"townName": "Barueri", '
                       '"ibgeCode": "3505708", '
                       '"countrySubDivision": "SP", '
                       '"postCode": "06455-000", '
                       '"country": "BRASIL", "countryCode": "BRA", '
                       '"geographicCoordinates": {"latitude": "-58,000", "longitude": "58,000"}}'
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.ENDERECO.value,
                        EnumSilverFields.COMPLEMENTO.value,
                        EnumSilverFields.BAIRRO.value,
                        EnumSilverFields.MUNICIPIO.value,
                        EnumSilverFields.UF.value,
                        EnumSilverFields.CEP.value,
                        EnumSilverFields.PAIS.value,
                        EnumSilverFields.COD_PAIS.value,
                        EnumSilverFields.LATITUDE.value,
                        EnumSilverFields.LONGITUDE.value,
                        EnumSilverFields.COD_IBGE.value,
                        EnumDbFields.ENDERECO_POSTAL.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.ENDERECO.value,
                   EnumTestJson.COMPLEMENTO.value,
                   EnumTestJson.BAIRRO.value,
                   EnumTestJson.MUNICIPIO.value,
                   EnumTestJson.UF.value,
                   EnumTestJson.CEP.value,
                   EnumTestJson.PAIS.value,
                   EnumTestJson.COD_PAIS.value,
                   EnumTestJson.LATITUDE.value,
                   EnumTestJson.LONGITUDE.value,
                   EnumTestJson.COD_IBGE.value)

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.ENDERECO.value,
                    EnumSilverFields.COMPLEMENTO.value,
                    EnumSilverFields.BAIRRO.value,
                    EnumSilverFields.MUNICIPIO.value,
                    EnumSilverFields.UF.value,
                    EnumSilverFields.CEP.value,
                    EnumSilverFields.PAIS.value,
                    EnumSilverFields.COD_PAIS.value,
                    EnumSilverFields.LATITUDE.value,
                    EnumSilverFields.LONGITUDE.value,
                    EnumSilverFields.COD_IBGE.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_postal_address_as_json(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_postal_address(spark_session):
    """ Test that the function get the postal address fields parsing the JSON format to pyspark.sql.types.StrucType """

    expected_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       CID_PRODT_COBER=EnumTestJson.COD_PRODUTO_COBERTURA.value,
                       EENDER_COPLT=EnumTestJson.ENDERECO.value,
                       ECOMPL=EnumTestJson.COMPLEMENTO.value,
                       EBAIRO=EnumTestJson.BAIRRO.value,
                       EMUN=EnumTestJson.MUNICIPIO.value,
                       EUF=EnumTestJson.UF.value,
                       ECEP=EnumTestJson.CEP.value,
                       EPAIS=EnumTestJson.PAIS.value,
                       ECOD_PAIS=EnumTestJson.COD_PAIS.value,
                       ELATTD=EnumTestJson.LATITUDE.value,
                       ELOGTD=EnumTestJson.LONGITUDE.value,
                       CIBGE=EnumTestJson.COD_IBGE.value,
                       postalAddress=Row(address=EnumTestJson.ENDERECO.value,
                                         additionalInfo=EnumTestJson.COMPLEMENTO.value,
                                         districtName=EnumTestJson.BAIRRO.value,
                                         townName=EnumTestJson.MUNICIPIO.value,
                                         ibgeCode=EnumTestJson.COD_IBGE.value,
                                         countrySubDivision=EnumTestJson.UF.value,
                                         postCode=EnumTestJson.CEP.value,
                                         country=EnumTestJson.PAIS.value,
                                         countryCode=EnumTestJson.COD_PAIS.value,
                                         geographicCoordinates=Row(latitude=EnumTestJson.LATITUDE.value,
                                                                   longitude=EnumTestJson.LONGITUDE.value)))

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.CODIGO_PRODUTO.value,
                        EnumSilverFields.ENDERECO.value,
                        EnumSilverFields.COMPLEMENTO.value,
                        EnumSilverFields.BAIRRO.value,
                        EnumSilverFields.MUNICIPIO.value,
                        EnumSilverFields.UF.value,
                        EnumSilverFields.CEP.value,
                        EnumSilverFields.PAIS.value,
                        EnumSilverFields.COD_PAIS.value,
                        EnumSilverFields.LATITUDE.value,
                        EnumSilverFields.LONGITUDE.value,
                        EnumSilverFields.COD_IBGE.value,
                        EnumDbFields.ENDERECO_POSTAL.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.COD_PRODUTO_COBERTURA.value,
                   EnumTestJson.ENDERECO.value,
                   EnumTestJson.COMPLEMENTO.value,
                   EnumTestJson.BAIRRO.value,
                   EnumTestJson.MUNICIPIO.value,
                   EnumTestJson.UF.value,
                   EnumTestJson.CEP.value,
                   EnumTestJson.PAIS.value,
                   EnumTestJson.COD_PAIS.value,
                   EnumTestJson.LATITUDE.value,
                   EnumTestJson.LONGITUDE.value,
                   EnumTestJson.COD_IBGE.value,
                   '{"address": "Alameda Araguaia, 2104 – Alphaville – Barueri-SP 23 e 24º. Andar - CEP: 06455-000", '
                   '"additionalInfo": "23 e 24º. Andar", '
                   '"districtName": "Alphaville", '
                   '"townName": "Barueri", '
                   '"ibgeCode": "3505708", '
                   '"countrySubDivision": "SP", '
                   '"postCode": "06455-000", '
                   '"country": "BRASIL", "countryCode": "BRA", '
                   '"geographicCoordinates": {"latitude": "-58,000", "longitude": "58,000"}}'
                   )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.CODIGO_PRODUTO.value,
                    EnumSilverFields.ENDERECO.value,
                    EnumSilverFields.COMPLEMENTO.value,
                    EnumSilverFields.BAIRRO.value,
                    EnumSilverFields.MUNICIPIO.value,
                    EnumSilverFields.UF.value,
                    EnumSilverFields.CEP.value,
                    EnumSilverFields.PAIS.value,
                    EnumSilverFields.COD_PAIS.value,
                    EnumSilverFields.LATITUDE.value,
                    EnumSilverFields.LONGITUDE.value,
                    EnumSilverFields.COD_IBGE.value,
                    EnumDbFields.ENDERECO_POSTAL.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_postal_address(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_postal_address_list(spark_session):
    """ Test that the function get the postal address fields parsing the JSON format to pyspark.sql.types.StrucType """

    mock_row = Row(IMARCA=EnumTestJson.MARCA.value,
                   ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                   NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                   IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   CID_PRODT_COBER=EnumTestJson.COD_PRODUTO_COBERTURA.value,
                   EENDER_COPLT=EnumTestJson.ENDERECO.value,
                   ECOMPL=EnumTestJson.COMPLEMENTO.value,
                   EBAIRO=EnumTestJson.BAIRRO.value,
                   EMUN=EnumTestJson.MUNICIPIO.value,
                   EUF=EnumTestJson.UF.value,
                   ECEP=EnumTestJson.CEP.value,
                   EPAIS=EnumTestJson.PAIS.value,
                   ECOD_PAIS=EnumTestJson.COD_PAIS.value,
                   ELATTD=EnumTestJson.LATITUDE.value,
                   ELOGTD=EnumTestJson.LONGITUDE.value,
                   CIBGE=EnumTestJson.COD_IBGE.value,
                   postalAddress=Row(address=EnumTestJson.ENDERECO.value,
                                     additionalInfo=EnumTestJson.COMPLEMENTO.value,
                                     districtName=EnumTestJson.BAIRRO.value,
                                     townName=EnumTestJson.MUNICIPIO.value,
                                     ibgeCode=EnumTestJson.COD_IBGE.value,
                                     countrySubDivision=EnumTestJson.UF.value,
                                     postCode=EnumTestJson.CEP.value,
                                     country=EnumTestJson.PAIS.value,
                                     countryCode=EnumTestJson.COD_PAIS.value,
                                     geographicCoordinates=Row(latitude=EnumTestJson.LATITUDE.value,
                                                               longitude=EnumTestJson.LONGITUDE.value)))

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.CODIGO_PRODUTO.value,
                    EnumSilverFields.ENDERECO.value,
                    EnumSilverFields.COMPLEMENTO.value,
                    EnumSilverFields.BAIRRO.value,
                    EnumSilverFields.MUNICIPIO.value,
                    EnumSilverFields.UF.value,
                    EnumSilverFields.CEP.value,
                    EnumSilverFields.PAIS.value,
                    EnumSilverFields.COD_PAIS.value,
                    EnumSilverFields.LATITUDE.value,
                    EnumSilverFields.LONGITUDE.value,
                    EnumSilverFields.COD_IBGE.value,
                    EnumDbFields.ENDERECO_POSTAL.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    expect_row = Row(IMARCA=EnumTestJson.MARCA.value,
                     ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                     NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                     IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                     NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                     postalAddress=[Row(address=EnumTestJson.ENDERECO.value,
                                        additionalInfo=EnumTestJson.COMPLEMENTO.value,
                                        districtName=EnumTestJson.BAIRRO.value,
                                        townName=EnumTestJson.MUNICIPIO.value,
                                        ibgeCode=EnumTestJson.COD_IBGE.value,
                                        countrySubDivision=EnumTestJson.UF.value,
                                        postCode=EnumTestJson.CEP.value,
                                        country=EnumTestJson.PAIS.value,
                                        countryCode=EnumTestJson.COD_PAIS.value,
                                        geographicCoordinates=Row(latitude=EnumTestJson.LATITUDE.value,
                                                                  longitude=EnumTestJson.LONGITUDE.value))])

    expect_columns = [EnumSilverFields.MARCA.value,
                      EnumSilverFields.NOME_SOCIEDADE.value,
                      EnumSilverFields.CNPJ_SOCIEDADE.value,
                      EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                      EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                      EnumDbFields.ENDERECO_POSTAL.value]

    expected = spark_session.createDataFrame([expect_row], expect_columns)

    # Act #
    result_spark = get_postal_address_list(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

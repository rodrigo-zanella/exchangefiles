import pytest
from pyspark.sql import Row
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_db_fields import EnumDbFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_json import EnumTestJson
from opin_lib_canais_rede_referenciada_dados.load.rede_referenciada import get_services_fields, \
    get_services_as_json, get_services, get_services_list


@pytest.mark.usefixtures("spark_session")
def test_get_services_fields(spark_session):
    """ Test that the function get the services fields """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.TIPO_SERVICOS_PRESTADOS.value,
                       EnumTestJson.TIPO_SERVICO_CONVERTIDO_OUTROS.value,
                       EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value,
                       EnumTestJson.DESCRICAO_TIPO_SERVICOS.value
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.TIPO_SERVICO.value,
                        EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                        EnumSilverFields.NOME_SERVICOS_PRESTADOS.value,
                        EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value,
                        ]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.TIPO_SERVICOS_PRESTADOS.value,
                   EnumTestJson.TIPO_SERVICO_CONVERTIDO_OUTROS.value,
                   EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value,
                   EnumTestJson.DESCRICAO_TIPO_SERVICOS.value
                   )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.TIPO_SERVICO.value,
                    EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                    EnumSilverFields.NOME_SERVICOS_PRESTADOS.value,
                    EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value
                    ]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_services_fields(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_services_as_json(spark_session):
    """ Test that the function get the services fields in JSON Format """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                       EnumTestJson.TIPO_SERVICO_CONVERTIDO_OUTROS.value,
                       EnumTestJson.DESCRICAO_TIPO_SERVICOS.value,
                       '{"type":"SERVICO_EM_CASO_DE_SINISTRO",'
                       '"typeOthers":"VALIDO",'
                       '"name":["EFETIVACAO_APORTE"],'
                       '"description":"NA"}'
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.TIPO_SERVICO.value,
                        EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                        EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value,
                        EnumDbFields.SERVICOS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                   EnumTestJson.TIPO_SERVICO_CONVERTIDO_OUTROS.value,
                   EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value,
                   EnumTestJson.DESCRICAO_TIPO_SERVICOS.value
                   )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.TIPO_SERVICO.value,
                    EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                    EnumSilverFields.NOME_SERVICOS_PRESTADOS.value,
                    EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value
                    ]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_services_as_json(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_services(spark_session):
    """ Test that the function get the services fields parsing the JSON format to pyspark.sql.types.StrucType """

    expected_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       RTPO_SERVC=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                       RTPO_SERVC_OUTROS=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                       RDESCR_TPO_SERVC=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value,
                       services=Row(type=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                                    typeOthers=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                                    name=[EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value],
                                    description=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value))

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.TIPO_SERVICO.value,
                        EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                        EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value,
                        EnumDbFields.SERVICOS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                   EnumTestJson.TIPO_SERVICO_CONVERTIDO_OUTROS.value,
                   EnumTestJson.DESCRICAO_TIPO_SERVICOS.value,
                   '{"type":"SERVICO_EM_CASO_DE_SINISTRO",'
                   '"typeOthers":"VALIDO",'
                   '"name":["EFETIVACAO_APORTE"],'
                   '"description":"NA"}'
                   )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.TIPO_SERVICO.value,
                    EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                    EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value,
                    EnumDbFields.SERVICOS.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_services(mock)

    expected.show(truncate=False)
    result_spark.show(truncate=False)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_services_list(spark_session):
    """ Test that the function get the services fields parsing the JSON format to pyspark.sql.types.StrucType """

    expected_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       services=[Row(type=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                                     typeOthers=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                                     name=[EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value],
                                     description=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value),
                                 Row(type=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM_CASE2.value,
                                     typeOthers=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                                     name=[EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value],
                                     description=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value)
                                 ])

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumDbFields.SERVICOS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = [Row(IMARCA=EnumTestJson.MARCA.value,
                    ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                    NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                    IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                    NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                    RTPO_SERVC=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                    RTPO_SERVC_OUTROS=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                    RDESCR_TPO_SERVC=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value,
                    services=Row(type=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                                 typeOthers=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                                 name=[EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value],
                                 description=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value)),
                Row(IMARCA=EnumTestJson.MARCA.value,
                    ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                    NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                    IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                    NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                    RTPO_SERVC=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM_CASE2.value,
                    RTPO_SERVC_OUTROS=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                    RDESCR_TPO_SERVC=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value,
                    services=Row(type=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM_CASE2.value,
                                 typeOthers=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                                 name=[EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value],
                                 description=EnumTestJson.DESCRICAO_TIPO_SERVICOS.value))
                ]

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.TIPO_SERVICO.value,
                    EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                    EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value,
                    EnumDbFields.SERVICOS.value]

    mock = spark_session.createDataFrame(mock_row, mock_columns)

    # Act #
    result_spark = get_services_list(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

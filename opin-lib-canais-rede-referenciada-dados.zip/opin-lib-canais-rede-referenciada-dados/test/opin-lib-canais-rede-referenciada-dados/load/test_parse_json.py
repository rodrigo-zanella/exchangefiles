import pytest
from pyspark.sql import Row
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_db_fields import EnumDbFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_json import EnumTestJson
from opin_lib_canais_rede_referenciada_dados.load.rede_referenciada import join_json_items


# join_json_items
@pytest.mark.usefixtures("spark_session")
def test_join_json_items(spark_session):
    """ Test join of all json items from identification, access, products, postal address and services. """

    expected_row = Row(brandName=EnumTestJson.MARCA.value,
                       companyName=EnumTestJson.NOME_SOCIEDADE.value,
                       cnpjNumber=EnumTestJson.CNPJ_SOCIEDADE.value,
                       identification=Row(referencedNetworkName=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                                          referencedNetworkCnpjNumber=EnumTestJson.CNPJ_REDE_REFERENCIADA.value),
                       products=[Row(name=EnumTestJson.NOME_PRODUTO.value,
                                     code=EnumTestJson.CODIGO_PRODUTO.value,
                                     coverage=[EnumTestJson.NOME_COBERTURA.value])],
                       postalAddress=Row(address=EnumTestJson.ENDERECO.value,
                                         additionalInfo=EnumTestJson.COMPLEMENTO.value,
                                         districtName=EnumTestJson.BAIRRO.value,
                                         townName=EnumTestJson.MUNICIPIO.value,
                                         countrySubDivision=EnumTestJson.UF.value,
                                         zipCode=EnumTestJson.CEP.value,
                                         country=EnumTestJson.PAIS.value,
                                         countryCode=EnumTestJson.COD_PAIS.value,
                                         geographicCoordinates=Row(latitude=EnumTestJson.LATITUDE.value,
                                                                   longitude=EnumTestJson.LONGITUDE.value)),
                       access=[Row(restrictionIndicator=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                                   phones=[Row(type=EnumTestJson.TIPO_TELEFONE.value,
                                               countryCallingCode=EnumTestJson.DDI.value,
                                               areaCode=EnumTestJson.DDD.value,
                                               number=EnumTestJson.NUM_TELEFONE.value)])],
                       services=[Row(type=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                                     typeOthers=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                                     name=[EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value],
                                     nameOthers=EnumTestJson.NOME_SERVICOS_PRESTADOS_OUTROS.value)],
                       rowId=EnumTestJson.ROW_ID.value
                       )

    expected_columns = [EnumDbFields.MARCA.value,
                        EnumDbFields.NOME_SOCIEDADE.value,
                        EnumDbFields.CNPJ_SOCIEDADE.value,
                        EnumDbFields.IDENTIFICACAO.value,
                        EnumDbFields.PRODUTOS.value,
                        EnumDbFields.ENDERECO_POSTAL.value,
                        EnumDbFields.FORMA_ACESSO.value,
                        EnumDbFields.SERVICOS.value,
                        EnumDbFields.ROW_ID.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    identification_row = Row(ROW_ID=EnumTestJson.ROW_ID.value,
                             IMARCA=EnumTestJson.MARCA.value,
                             ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                             NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                             IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                             NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                             identification=Row(referencedNetworkName=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                                                referencedNetworkCnpjNumber=EnumTestJson.CNPJ_REDE_REFERENCIADA.value)
                             )

    identification_columns = [EnumSilverFields.ROW_ID.value,
                              EnumSilverFields.MARCA.value,
                              EnumSilverFields.NOME_SOCIEDADE.value,
                              EnumSilverFields.CNPJ_SOCIEDADE.value,
                              EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                              EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                              EnumDbFields.IDENTIFICACAO.value]

    identification = spark_session.createDataFrame([identification_row], identification_columns)

    products_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       products=[Row(name=EnumTestJson.NOME_PRODUTO.value,
                                     code=EnumTestJson.CODIGO_PRODUTO.value,
                                     coverage=[EnumTestJson.NOME_COBERTURA.value])])

    products_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumDbFields.PRODUTOS.value]

    products = spark_session.createDataFrame([products_row], products_columns)

    postal_address_row = Row(IMARCA=EnumTestJson.MARCA.value,
                             ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                             NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                             IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                             NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                             CID_PRODT_COBER=EnumTestJson.COD_PRODUTO_COBERTURA.value,
                             EENDER_COPLT=EnumTestJson.ENDERECO.value,
                             ECOMPL=EnumTestJson.COMPLEMENTO.value,
                             EBAIRO=EnumTestJson.BAIRRO.value,
                             EMUN=EnumTestJson.MUNICIPIO.value,
                             EUF=EnumTestJson.UF.value,
                             ECEP=EnumTestJson.CEP.value,
                             EPAIS=EnumTestJson.PAIS.value,
                             ECOD_PAIS=EnumTestJson.COD_PAIS.value,
                             ELATTD=EnumTestJson.LATITUDE.value,
                             ELOGTD=EnumTestJson.LONGITUDE.value,
                             postalAddress=Row(address=EnumTestJson.ENDERECO.value,
                                               additionalInfo=EnumTestJson.COMPLEMENTO.value,
                                               districtName=EnumTestJson.BAIRRO.value,
                                               townName=EnumTestJson.MUNICIPIO.value,
                                               countrySubDivision=EnumTestJson.UF.value,
                                               zipCode=EnumTestJson.CEP.value,
                                               country=EnumTestJson.PAIS.value,
                                               countryCode=EnumTestJson.COD_PAIS.value,
                                               geographicCoordinates=Row(latitude=EnumTestJson.LATITUDE.value,
                                                                         longitude=EnumTestJson.LONGITUDE.value)))

    postal_address_columns = [EnumSilverFields.MARCA.value,
                              EnumSilverFields.NOME_SOCIEDADE.value,
                              EnumSilverFields.CNPJ_SOCIEDADE.value,
                              EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                              EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                              EnumSilverFields.CODIGO_PRODUTO.value,
                              EnumSilverFields.ENDERECO.value,
                              EnumSilverFields.COMPLEMENTO.value,
                              EnumSilverFields.BAIRRO.value,
                              EnumSilverFields.MUNICIPIO.value,
                              EnumSilverFields.UF.value,
                              EnumSilverFields.CEP.value,
                              EnumSilverFields.PAIS.value,
                              EnumSilverFields.COD_PAIS.value,
                              EnumSilverFields.LATITUDE.value,
                              EnumSilverFields.LONGITUDE.value,
                              EnumDbFields.ENDERECO_POSTAL.value]

    postal_address = spark_session.createDataFrame([postal_address_row], postal_address_columns)

    access_row = Row(IMARCA=EnumTestJson.MARCA.value,
                     ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                     NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                     IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                     NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                     access=[Row(restrictionIndicator=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                                 phones=[Row(type=EnumTestJson.TIPO_TELEFONE.value,
                                             countryCallingCode=EnumTestJson.DDI.value,
                                             areaCode=EnumTestJson.DDD.value,
                                             number=EnumTestJson.NUM_TELEFONE.value)])])

    access_columns = [EnumSilverFields.MARCA.value,
                      EnumSilverFields.NOME_SOCIEDADE.value,
                      EnumSilverFields.CNPJ_SOCIEDADE.value,
                      EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                      EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                      EnumDbFields.FORMA_ACESSO.value]

    access = spark_session.createDataFrame([access_row], access_columns)

    services_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       services=[Row(type=EnumTestJson.TIPO_SERVICO_PRESTADO_ENUM.value,
                                     typeOthers=EnumTestJson.TIPO_SERVICO_OUTROS.value,
                                     name=[EnumTestJson.NOME_SERVICOS_PRESTADOS_ENUM.value],
                                     nameOthers=EnumTestJson.NOME_SERVICOS_PRESTADOS_OUTROS.value)])

    services_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumDbFields.SERVICOS.value]

    services = spark_session.createDataFrame([services_row], services_columns)

    # Act #
    result_spark = join_json_items(identification, products, postal_address, access, services)

    expected.show(truncate=False)
    result_spark.show(truncate=False)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

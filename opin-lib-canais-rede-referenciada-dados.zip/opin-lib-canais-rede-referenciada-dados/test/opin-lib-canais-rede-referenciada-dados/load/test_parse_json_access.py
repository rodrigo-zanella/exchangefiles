import pytest
from pyspark.sql import Row
import pyspark.sql.types as T
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_db_fields import EnumDbFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_json import EnumTestJson
from opin_lib_canais_rede_referenciada_dados.load.rede_referenciada import get_access_fields, get_access_as_json, \
    get_access, get_access_list, get_access_standards_as_list, get_access_phones_as_list


@pytest.mark.usefixtures("spark_session")
def test_get_access_fields(spark_session):
    """ Test that the function get the access fields """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                       EnumTestJson.TIPO_TELEFONE.value,
                       EnumTestJson.DDI.value,
                       EnumTestJson.DDD.value,
                       EnumTestJson.NUM_TELEFONE.value,
                       EnumTestJson.DIAS_FUNCIONAMENTO.value,
                       EnumTestJson.HORARIO_ABERTURA.value,
                       EnumTestJson.HORARIO_ENCERRAMENTO.value
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                        EnumSilverFields.TIPO_TELEFONE.value,
                        EnumSilverFields.DDI.value,
                        EnumSilverFields.DDD.value,
                        EnumSilverFields.NUM_TELEFONE.value,
                        EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                        EnumSilverFields.HORARIO_ABERTURA.value,
                        EnumSilverFields.HORARIO_ENCERRAMENTO.value
                        ]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                   EnumTestJson.TIPO_TELEFONE.value,
                   EnumTestJson.DDI.value,
                   EnumTestJson.DDD.value,
                   EnumTestJson.NUM_TELEFONE.value,
                   EnumTestJson.ENDERECO.value,
                   EnumTestJson.CEP.value,
                   EnumTestJson.DIAS_FUNCIONAMENTO.value,
                   EnumTestJson.HORARIO_ABERTURA.value,
                   EnumTestJson.HORARIO_ENCERRAMENTO.value
                   )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                    EnumSilverFields.TIPO_TELEFONE.value,
                    EnumSilverFields.DDI.value,
                    EnumSilverFields.DDD.value,
                    EnumSilverFields.NUM_TELEFONE.value,
                    EnumSilverFields.ENDERECO.value,
                    EnumSilverFields.CEP.value,
                    EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                    EnumSilverFields.HORARIO_ABERTURA.value,
                    EnumSilverFields.HORARIO_ENCERRAMENTO.value
                    ]

    mock = spark_session.createDataFrame([mock_row], mock_columns)


    # Act #
    result_spark = get_access_fields(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_access_as_json(spark_session):
    """ Test that the function get the access fields in JSON Format """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                       '{"standards":[],'
                       '"restrictionIndicator":false,'
                       '"phones":[{"type":"FIXO",'
                       '"countryCallingCode":"55",'
                       '"areaCode":"21",'
                       '"number":"40042757"}]}'
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                        EnumDbFields.FORMA_ACESSO.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.DIAS_FUNCIONAMENTO_VAZIO.value,
                   EnumTestJson.HORARIO_ABERTURA_VAZIO.value,
                   EnumTestJson.HORARIO_ENCERRAMENTO_VAZIO.value,
                   EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                   EnumTestJson.TIPO_TELEFONE.value,
                   EnumTestJson.DDI.value,
                   EnumTestJson.DDD.value,
                   EnumTestJson.NUM_TELEFONE.value)

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                    EnumSilverFields.HORARIO_ABERTURA.value,
                    EnumSilverFields.HORARIO_ENCERRAMENTO.value,
                    EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                    EnumSilverFields.TIPO_TELEFONE.value,
                    EnumSilverFields.DDI.value,
                    EnumSilverFields.DDD.value,
                    EnumSilverFields.NUM_TELEFONE.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)
    standard = get_access_standards_as_list(mock)
    phones = get_access_phones_as_list(mock)

    # Act #
    result_spark = get_access_as_json(standard,phones)
    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_access(spark_session):
    """ Test that the function get the access fields parsing the JSON format to pyspark.sql.types.StrucType """

    expected_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       RINDCD_REST_ACSSO=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                       access=Row(
                           standards=[Row(
                               openingTime=EnumTestJson.HORARIO_ABERTURA_VAZIO.value,
                               closingTime=EnumTestJson.HORARIO_ENCERRAMENTO_VAZIO.value,
                               weekday=EnumTestJson.DIAS_FUNCIONAMENTO_VAZIO.value,
                           )],
                           restrictionIndicator=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                           phones=[Row(type=EnumTestJson.TIPO_TELEFONE.value,
                                       countryCallingCode=EnumTestJson.DDI.value,
                                       areaCode=EnumTestJson.DDD.value,
                                       number=EnumTestJson.NUM_TELEFONE.value)]))

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                        EnumDbFields.FORMA_ACESSO.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                   '{"standards":['
                   '{'
                   '"openingTime":"",'
                   '"closingTime":"",'
                   '"weekday":""'
                   '}'
                   '],'
                   '"restrictionIndicator":false,'
                   '"phones":[{"type":"FIXO",'
                   '"countryCallingCode":"55",'
                   '"areaCode":"21",'
                   '"number":"40042757"}]}'
                   )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                    EnumDbFields.FORMA_ACESSO.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_access(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_access_list(spark_session):
    """ Test that the function get the access list """

    expected_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       access=[Row(restrictionIndicator=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                                   phones=[Row(type=EnumTestJson.TIPO_TELEFONE.value,
                                               countryCallingCode=EnumTestJson.DDI.value,
                                               areaCode=EnumTestJson.DDD.value,
                                               number=EnumTestJson.NUM_TELEFONE.value)]),
                               Row(restrictionIndicator=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                                   phones=[Row(type=EnumTestJson.TIPO_TELEFONE.value,
                                               countryCallingCode=EnumTestJson.DDI.value,
                                               areaCode=EnumTestJson.DDD.value,
                                               number=EnumTestJson.NUM_TELEFONE_CASE2.value)])
                               ])

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumDbFields.FORMA_ACESSO.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = [
        Row(IMARCA=EnumTestJson.MARCA.value,
            ISOC=EnumTestJson.NOME_SOCIEDADE.value,
            NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
            IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
            NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
            CID_PRODT_COBER=EnumTestJson.CODIGO_PRODUTO.value,
            RINDCD_REST_ACSSO=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
            access=Row(restrictionIndicator=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                       phones=[Row(type=EnumTestJson.TIPO_TELEFONE.value,
                                   countryCallingCode=EnumTestJson.DDI.value,
                                   areaCode=EnumTestJson.DDD.value,
                                   number=EnumTestJson.NUM_TELEFONE.value)])),
        Row(IMARCA=EnumTestJson.MARCA.value,
            ISOC=EnumTestJson.NOME_SOCIEDADE.value,
            NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
            IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
            NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
            CID_PRODT_COBER=EnumTestJson.CODIGO_PRODUTO.value,
            RINDCD_REST_ACSSO=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
            access=Row(restrictionIndicator=EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                       phones=[Row(type=EnumTestJson.TIPO_TELEFONE.value,
                                   countryCallingCode=EnumTestJson.DDI.value,
                                   areaCode=EnumTestJson.DDD.value,
                                   number=EnumTestJson.NUM_TELEFONE_CASE2.value)]))
    ]

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.CODIGO_PRODUTO.value,
                    EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                    EnumDbFields.FORMA_ACESSO.value]

    mock = spark_session.createDataFrame(mock_row, mock_columns)

    # Act #
    result_spark = get_access_list(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_access_standards_as_list(spark_session):
    """ Test that the function get the access fields in JSON Format """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                       '[]'
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                        EnumDbFields.FUNCIONAMENTO.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.DIAS_FUNCIONAMENTO_VAZIO.value,
                   EnumTestJson.HORARIO_ABERTURA_VAZIO.value,
                   EnumTestJson.HORARIO_ENCERRAMENTO_VAZIO.value,
                   EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                   EnumTestJson.TIPO_TELEFONE.value,
                   EnumTestJson.DDI.value,
                   EnumTestJson.DDD.value,
                   EnumTestJson.NUM_TELEFONE.value)

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                    EnumSilverFields.HORARIO_ABERTURA.value,
                    EnumSilverFields.HORARIO_ENCERRAMENTO.value,
                    EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                    EnumSilverFields.TIPO_TELEFONE.value,
                    EnumSilverFields.DDI.value,
                    EnumSilverFields.DDD.value,
                    EnumSilverFields.NUM_TELEFONE.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)
    # Act #
    result_spark = get_access_standards_as_list(mock)
    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_access_phones_as_list(spark_session):
    """ Test that the function get the access fields in JSON Format """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                       '[{"type":"FIXO",'
                       '"countryCallingCode":"55",'
                       '"areaCode":"21",'
                       '"number":"40042757"}]'
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                        EnumDbFields.TELEFONES.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.DIAS_FUNCIONAMENTO_VAZIO.value,
                   EnumTestJson.HORARIO_ABERTURA_VAZIO.value,
                   EnumTestJson.HORARIO_ENCERRAMENTO_VAZIO.value,
                   EnumTestJson.INDICADOR_RESTRICAO_ACESSO.value,
                   EnumTestJson.TIPO_TELEFONE.value,
                   EnumTestJson.DDI.value,
                   EnumTestJson.DDD.value,
                   EnumTestJson.NUM_TELEFONE.value)

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                    EnumSilverFields.HORARIO_ABERTURA.value,
                    EnumSilverFields.HORARIO_ENCERRAMENTO.value,
                    EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                    EnumSilverFields.TIPO_TELEFONE.value,
                    EnumSilverFields.DDI.value,
                    EnumSilverFields.DDD.value,
                    EnumSilverFields.NUM_TELEFONE.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)
    # Act #
    result_spark = get_access_phones_as_list(mock)
    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

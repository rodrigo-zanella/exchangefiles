import pytest
from pyspark.sql import Row
import pyspark.sql.types as T
from pyspark_test import assert_pyspark_df_equal
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_db_fields import EnumDbFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_test_json import EnumTestJson
from opin_lib_canais_rede_referenciada_dados.load.rede_referenciada import get_products_as_json, get_products, \
    get_products_list


@pytest.mark.usefixtures("spark_session")
def test_get_products_as_json(spark_session):
    """ Test that the function get the products fields in JSON Format """

    expected_row = Row(EnumTestJson.MARCA.value,
                       EnumTestJson.NOME_SOCIEDADE.value,
                       EnumTestJson.CNPJ_SOCIEDADE.value,
                       EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       EnumTestJson.NOME_PRODUTO.value,
                       EnumTestJson.CODIGO_PRODUTO.value,
                       '{"name": "Seguro Automotivo", "code": "305", "coverage":["Cobertura Auto"]}'
                       )

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.NOME_PRODUTO.value,
                        EnumSilverFields.CODIGO_PRODUTO.value,
                        EnumDbFields.PRODUTOS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.NOME_PRODUTO.value,
                   EnumTestJson.CODIGO_PRODUTO.value,
                   EnumTestJson.NOME_COBERTURA.value)

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.NOME_PRODUTO.value,
                    EnumSilverFields.CODIGO_PRODUTO.value,
                    EnumSilverFields.NOME_COBERTURA.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_products_as_json(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_products(spark_session):
    """ Test that the function get the products fields parsing the JSON format to pyspark.sql.types.StrucType """

    expected_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       NPRODT=EnumTestJson.NOME_PRODUTO.value,
                       CID_PRODT=EnumTestJson.CODIGO_PRODUTO.value,
                       products=Row(name=EnumTestJson.NOME_PRODUTO.value,
                                    code=EnumTestJson.CODIGO_PRODUTO.value,
                                    coverage=[EnumTestJson.NOME_COBERTURA.value]))

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumSilverFields.NOME_PRODUTO.value,
                        EnumSilverFields.CODIGO_PRODUTO.value,
                        EnumDbFields.PRODUTOS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = Row(EnumTestJson.MARCA.value,
                   EnumTestJson.NOME_SOCIEDADE.value,
                   EnumTestJson.CNPJ_SOCIEDADE.value,
                   EnumTestJson.NOME_REDE_REFERENCIADA.value,
                   EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                   EnumTestJson.NOME_PRODUTO.value,
                   EnumTestJson.CODIGO_PRODUTO.value,
                   '{"name": "Seguro Automotivo", "code": "305", "coverage":["Cobertura Auto"]}'
                   )

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.NOME_PRODUTO.value,
                    EnumSilverFields.CODIGO_PRODUTO.value,
                    EnumDbFields.PRODUTOS.value]

    mock = spark_session.createDataFrame([mock_row], mock_columns)

    # Act #
    result_spark = get_products(mock)

    expected.show(truncate=False)
    result_spark.show(truncate=False)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)


@pytest.mark.usefixtures("spark_session")
def test_get_products_list(spark_session):
    """ Test that the function get the products list """

    expected_row = Row(IMARCA=EnumTestJson.MARCA.value,
                       ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                       NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                       IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                       NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                       products=[Row(name=EnumTestJson.NOME_PRODUTO.value,
                                     code=EnumTestJson.CODIGO_PRODUTO.value,
                                     coverage=[EnumTestJson.NOME_COBERTURA.value]),
                                 Row(name=EnumTestJson.NOME_PRODUTO_CASE2.value,
                                     code=EnumTestJson.CODIGO_PRODUTO_CASE2.value,
                                     coverage=[EnumTestJson.NOME_COBERTURA.value])
                                 ])

    expected_columns = [EnumSilverFields.MARCA.value,
                        EnumSilverFields.NOME_SOCIEDADE.value,
                        EnumSilverFields.CNPJ_SOCIEDADE.value,
                        EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                        EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                        EnumDbFields.PRODUTOS.value]

    expected = spark_session.createDataFrame([expected_row], expected_columns)

    mock_row = [Row(IMARCA=EnumTestJson.MARCA.value,
                    ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                    NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                    IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                    NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                    NPRODT=EnumTestJson.NOME_PRODUTO.value,
                    CID_PRODT=EnumTestJson.CODIGO_PRODUTO.value,
                    products=Row(name=EnumTestJson.NOME_PRODUTO.value,
                                 code=EnumTestJson.CODIGO_PRODUTO.value,
                                 coverage=[EnumTestJson.NOME_COBERTURA.value])),
                Row(IMARCA=EnumTestJson.MARCA.value,
                    ISOC=EnumTestJson.NOME_SOCIEDADE.value,
                    NCNPJ_SOC=EnumTestJson.CNPJ_SOCIEDADE.value,
                    IPRETR_SERVC=EnumTestJson.NOME_REDE_REFERENCIADA.value,
                    NCNPJ_PRETR_SERVC=EnumTestJson.CNPJ_REDE_REFERENCIADA.value,
                    NPRODT=EnumTestJson.NOME_PRODUTO.value,
                    CID_PRODT=EnumTestJson.CODIGO_PRODUTO.value,
                    products=Row(name=EnumTestJson.NOME_PRODUTO_CASE2.value,
                                 code=EnumTestJson.CODIGO_PRODUTO_CASE2.value,
                                 coverage=[EnumTestJson.NOME_COBERTURA.value]))
                ]

    mock_columns = [EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                    EnumSilverFields.NOME_PRODUTO.value,
                    EnumSilverFields.CODIGO_PRODUTO.value,
                    EnumDbFields.PRODUTOS.value]

    mock = spark_session.createDataFrame(mock_row, mock_columns)

    # Act #
    result_spark = get_products_list(mock)

    # Assert #
    assert_pyspark_df_equal(result_spark, expected)

from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from pyspark.sql.session import SparkSession
import pytest


@pytest.fixture
def spark_session_old():
    env = Environment()
    if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
        dbutils = None
        spark = None

    context = Context(spark, env, dbutils)
    spark_session = context.spark

    return spark_session


@pytest.fixture
def spark_session():
    return(SparkSession.builder
           .enableHiveSupport()
           .getOrCreate())
# Databricks notebook source
import os
if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system("pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------

from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.ingestion.ingestion_functions import ingestion
from pymongo import MongoClient

env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils

# COMMAND ----------

client = MongoClient(context.COSMOSDB_URI_CANAIS)
db = client[context.COSMOSDB_DATABASE_CANAIS]
collection = db[context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA]
colecao = collection.find()

data = list(collection.find({}, {"_id": 1, }))
type(data[1].get('_id'))

# COMMAND ----------

n = 1
lista_ids = [[i, value.get('_id')] for i, value in enumerate(data, 1)]

# COMMAND ----------

inicio = 1
fim = 500
list_df = []
list_id_part = []
size = len(lista_ids)
for id in lista_ids:
    if (inicio < fim):
        list_id_part.append(id[1])
        inicio = inicio + 1
    else:
        list_df.append(list_id_part)
        inicio = 1
        list_id_part = []

# COMMAND ----------

for row in list_df:
    list1 = []
    for i in row:
        list1.append(i)

    del_query = {
        "_id": {
            "$in": list1
        }
    }

    client = MongoClient(context.COSMOSDB_URI_CANAIS)
    db = client[context.COSMOSDB_DATABASE_CANAIS]
    collection = db[context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA]

    collection.delete_many(del_query)

# COMMAND ----------

# caso sobre registros
client = MongoClient(context.COSMOSDB_URI_CANAIS)
db = client[context.COSMOSDB_DATABASE_CANAIS]
collection = db[context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA]

collection.delete_many({})

# COMMAND ----------

client = MongoClient(context.COSMOSDB_URI_CANAIS)
db = client[context.COSMOSDB_DATABASE_CANAIS]
collection = db[context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA]

colecao = collection.find()

print(colecao.collection.count_documents({}))

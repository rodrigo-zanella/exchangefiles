# COMMAND ----------
# DBTITLE 1,Install Lib
import os
if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system("pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------
# DBTITLE 1, Purge
from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.purge.purge_functions import purge

env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils

purge(spark, context.STORAGE_BRONZE_REDE_REFERENCIADA)

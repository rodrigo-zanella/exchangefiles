# COMMAND ----------
# DBTITLE 1,Install Lib
import os
if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system("pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------

# DBTITLE 1,Imports
from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_db_fields import EnumDbFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.load.rede_referenciada import get_identification_as_json, \
    get_postal_address_as_json, get_identification, get_postal_address, get_services_fields, \
    get_services_as_json, get_services, join_json_items, get_products_as_json, get_products_list, get_products, \
    get_access_fields, get_access_as_json, get_access, get_access_list, \
    get_postal_address_list, get_services_list, get_access_phones_as_list, get_access_standards_as_list
from opin_lib_canais_rede_referenciada_dados.storage_functions import read_delta_file, delete_cosmosdb

# COMMAND ----------

# DBTITLE 1,Initialize
env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils

# COMMAND ----------

# DBTITLE 1,Read
rede_referenciada_silver = read_delta_file(dbutils, spark, context.STORAGE_SILVER_REDE_REFERENCIADA)
rede_referenciada_deleted_records = read_delta_file(dbutils, spark, context.STORAGE_SILVER_REDE_REFERENCIADA_DELETADOS)

# COMMAND ----------

# DBTITLE 1,Identification
rede_referenciada_identification_json = get_identification_as_json(rede_referenciada_silver)
rede_referenciada_identification = get_identification(rede_referenciada_identification_json)

# COMMAND ----------

# DBTITLE 1,Products
rede_referenciada_products_json = get_products_as_json(rede_referenciada_silver)
rede_referenciada_products = get_products(rede_referenciada_products_json)
rede_referenciada_products_list = get_products_list(rede_referenciada_products)

# COMMAND ----------

# DBTITLE 1,Postal Address
rede_referenciada_postal_address_json = get_postal_address_as_json(rede_referenciada_silver)
rede_referenciada_postal_address = get_postal_address(rede_referenciada_postal_address_json)
rede_referenciada_postal_address_list = get_postal_address_list(rede_referenciada_postal_address)

# COMMAND ----------

# DBTITLE 1,Access
rede_referenciada_standards_access = get_access_standards_as_list(rede_referenciada_silver)
rede_referenciada_phones_access = get_access_phones_as_list(rede_referenciada_silver)
rede_referenciada_access_json = get_access_as_json(rede_referenciada_standards_access,
                                                   rede_referenciada_phones_access)
rede_referenciada_access = get_access(rede_referenciada_access_json)
rede_referenciada_access_list = get_access_list(rede_referenciada_access)

# COMMAND ----------

# DBTITLE 1,Services
rede_referenciada_services_fields = get_services_fields(rede_referenciada_silver)
rede_referenciada_services_json = get_services_as_json(rede_referenciada_services_fields)
rede_referenciada_services = get_services(rede_referenciada_services_json)
rede_referenciada_services_list = get_services_list(rede_referenciada_services)

# COMMAND ----------

# DBTITLE 1,Join
rede_referenciada = join_json_items(rede_referenciada_identification, rede_referenciada_products_list,
                                    rede_referenciada_postal_address_list, rede_referenciada_access_list,
                                    rede_referenciada_services_list)

# COMMAND ----------

rede_referenciada.display()

# COMMAND ----------

# DBTITLE 1,Delete and Upsert Cosmos DB
delete_cosmosdb(rede_referenciada_deleted_records, context.COSMOSDB_URI_CANAIS, context.COSMOSDB_DATABASE_CANAIS,
                context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA, EnumSilverFields.ROW_ID.value,
                EnumDbFields.ROW_ID.value)

# COMMAND ----------

# DBTITLE 1,Update records
keys = '{' + f"{EnumDbFields.CNPJ_SOCIEDADE.value}" + ':1,' + f"{EnumDbFields.ROW_ID.value}" + ':1}'

rede_referenciada.write \
    .option("uri", context.COSMOSDB_URI_CANAIS) \
    .option("database", context.COSMOSDB_DATABASE_CANAIS) \
    .option("collection", context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA) \
    .option("replaceDocument", "true") \
    .option('shardKey', f"{keys}") \
    .option("forceInsert", "true") \
    .option("maxBatchSize", 16) \
    .option("ordered", "false") \
    .mode('append') \
    .format("com.mongodb.spark.sql") \
    .save()

# COMMAND ----------
# DBTITLE 1,Install Lib
import os
if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system("pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------

# DBTITLE 1,Imports
from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_columns_list import EnumColumnsList
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_schemas import EnumSchemas
from opin_lib_canais_rede_referenciada_dados.storage_functions import read_delta_file, write_delta_file, \
    read_delta_file_or_return_empty
from opin_lib_canais_rede_referenciada_dados.transformation.rede_referenciada import mandatory_field_validator, \
    remove_final_delimiter_multivalues_fields, remove_numerical_masks, \
    explode_multivalues_fields, trim_fields, field_length_validator, rename_bronze_to_silver_columns, \
    filter_invalid_data, filter_valid_data, filter_deleted_records, \
    create_row_id_field, treat_null_boolean_fields, treat_null_values, \
    remove_accents_and_special_characters_from_fields, translate_options_from_enum, options_validator, \
    remove_accents_and_special_characters_to_referenced_name, exploded_product_code_and_name, treat_coverage_length, treat_weekday

env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils

# COMMAND ----------

# DBTITLE 1,Read
rede_referenciada_bronze = read_delta_file(dbutils, spark, context.STORAGE_BRONZE_REDE_REFERENCIADA)
rede_referenciada_silver = read_delta_file_or_return_empty(dbutils, spark, context.STORAGE_SILVER_REDE_REFERENCIADA,
                                                           EnumSchemas.SILVER_SCHEMA.value)

# COMMAND ----------

# DBTITLE 1,Explode and Normalize
rede_referenciada_final_delimiter_removed = remove_final_delimiter_multivalues_fields(rede_referenciada_bronze,
                                                                                      EnumColumnsList.MULTIVALUES_FIELDS.value,
                                                                                      ";")
rede_referenciada_numerical_masks_removed = remove_numerical_masks(rede_referenciada_final_delimiter_removed,
                                                                   EnumColumnsList.COLUMNS_WITH_MASK.value)

rede_referenciada_exploded = explode_multivalues_fields(rede_referenciada_numerical_masks_removed,
                                                        EnumColumnsList.COLUMNS_TO_EXPLODE.value, ";")

rede_referenciada_exploded_code_and_name_products = exploded_product_code_and_name(rede_referenciada_exploded)
rede_referenciada_trim = trim_fields(rede_referenciada_exploded_code_and_name_products)

rede_referenciada_normalize_name = remove_accents_and_special_characters_to_referenced_name(rede_referenciada_trim)
rede_referenciada_without_accents = remove_accents_and_special_characters_from_fields(rede_referenciada_normalize_name)
rede_referenciada_boolean_treated = treat_null_boolean_fields(rede_referenciada_without_accents)
rede_referenciada_null_optional_treated = treat_null_values(rede_referenciada_boolean_treated,
                                                            EnumColumnsList.COLUMNS_TO_TREAT.value)
rede_referenciada_coverage_treated = treat_coverage_length(rede_referenciada_null_optional_treated)
rede_referenciada_weekday_treated = treat_weekday(rede_referenciada_coverage_treated)

# COMMAND ----------

# DBTITLE 1,Data Quality
rede_referenciada_mandatory_field_validated = mandatory_field_validator(rede_referenciada_weekday_treated)
rede_referenciada_field_length_validated = field_length_validator(rede_referenciada_mandatory_field_validated)
rede_referenciada_options_validated = options_validator(rede_referenciada_field_length_validated)

# COMMAND ----------

# DBTITLE 1,Products invalid
rede_referenciada_invalid_filter = filter_invalid_data(rede_referenciada_options_validated)
rede_referenciada_invalid = rename_bronze_to_silver_columns(rede_referenciada_invalid_filter)
write_delta_file(rede_referenciada_invalid, context.STORAGE_SILVER_REDE_REFERENCIADA_INVALIDOS, "overwrite")

# COMMAND ----------

rede_referenciada_invalid.display()

# COMMAND ----------

# DBTITLE 1,Products valid, deleted and treatment
rede_referenciada_enum_translated = translate_options_from_enum(rede_referenciada_options_validated)
rede_referenciada_boolean_treated = treat_null_boolean_fields(rede_referenciada_enum_translated)
rede_referenciada_null_optional_treated = treat_null_values(rede_referenciada_boolean_treated,
                                                            EnumColumnsList.COLUMNS_TO_TREAT.value)
rede_referenciada_renamed = rename_bronze_to_silver_columns(rede_referenciada_null_optional_treated)
rede_referenciada_valid = filter_valid_data(rede_referenciada_renamed)
rede_referenciada_deleted = filter_deleted_records(spark, rede_referenciada_valid, rede_referenciada_silver)
rede_referenciada = create_row_id_field(rede_referenciada_valid)

# COMMAND ----------

# DBTITLE 1,Load
write_delta_file(rede_referenciada_deleted, context.STORAGE_SILVER_REDE_REFERENCIADA_DELETADOS, "overwrite")
write_delta_file(rede_referenciada, context.STORAGE_SILVER_REDE_REFERENCIADA, "overwrite")

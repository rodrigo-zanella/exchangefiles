# Databricks notebook source
# MAGIC %sh pip uninstall -y opin_lib_canais_rede_referenciada_dados

# COMMAND ----------

# DBTITLE 1,Install Lib
import os
if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system("pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------

# DBTITLE 1, Imports
from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.ingestion.ingestion_functions import ingestion

# COMMAND ----------

# DBTITLE 1,Initialize
env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils

# COMMAND ----------

# DBTITLE 1,Ingestion
ingestion(dbutils, spark,
          context.STORAGE_TRANSIENT_REDE_REFERENCIADA,
          context.STORAGE_BRONZE_REDE_REFERENCIADA, "csv", True, False, "|", env)

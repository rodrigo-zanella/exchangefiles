# COMMAND ----------
# MAGIC %sh pip uninstall -y opin_lib_canais_rede_referenciada_dados

# COMMAND ----------

import os

if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system(
        "pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------


from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from pymongo import MongoClient

env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils

# COMMAND ----------

client = MongoClient(context.COSMOSDB_URI_CANAIS)
db = client[context.COSMOSDB_DATABASE_CANAIS]
collection = db[context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA]
colecao = collection.find()

import pandas as pd

df = pd.DataFrame(list(collection.find()),
                  columns=['_id', 'brandName', 'companyName', 'cnpjNumber', 'rowId', 'identification', 'products',
                           'postalAddress', 'access', 'services', 'rowId'])

# COMMAND ----------

df_id = df[['_id']]

# COMMAND ----------

id_lista = []
for i in df_id.values.tolist():
    id_lista.append(str(i[0]))

# COMMAND ----------

import bson
from pyspark.sql.types import StructType, StructField, StringType

spark.conf.set("spark.sql.execution.arrow.enabled", "true")
schema = StructType([StructField("value", StringType(), True)])

df_rowid = spark.createDataFrame(id_lista, StringType())

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
import pyspark.sql.functions as f

# order by any column to populate the row number
window = Window.orderBy('value')
length = df_rowid.count()
df_Row_Id = df_rowid.withColumn('row', f.row_number().over(window))

# COMMAND ----------

df_Row_Id.count()

# COMMAND ----------

inicio = 1
fim = 500
cont = 1
list_df = []
size = df_Row_Id.count()
while inicio <= size:
    list_df.append(df_Row_Id.filter((f.col('row') >= inicio) & (f.col('row') <= fim)))
    inicio = fim + 1
    fim = inicio + 500
    cont = cont + 1

# COMMAND ----------

list_row_id = []
for df_ids in list_df:
    list_row_id.append([str(row.value) for row in df_ids.collect()])

# COMMAND ----------

len(list_row_id)

# COMMAND ----------

from bson.objectid import ObjectId

for row in list_row_id:
    list1 = []
    for i in row:
        list1.append(ObjectId(str(i)))

    del_query = {
        "_id": {
            "$in": list1
        }
    }

    client = MongoClient(context.COSMOSDB_URI_CANAIS)
    db = client[context.COSMOSDB_DATABASE_CANAIS]
    collection = db[context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA]

    collection.delete_many(del_query)

# COMMAND ----------

# caso sobre um pouco de registros
client = MongoClient(context.COSMOSDB_URI_CANAIS)
db = client[context.COSMOSDB_DATABASE_CANAIS]
collection = db[context.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA]

collection.delete_many({})

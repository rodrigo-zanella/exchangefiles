# Databricks notebook source
import os

if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system(
        "pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------

from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.ingestion.ingestion_functions import ingestion
from opin_lib_canais_rede_referenciada_dados.storage_functions import read_db_sqlserver, write_db_sqlserver, \
    read_delta_file
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.functions import row_number, current_timestamp
from pyspark.sql.window import Window
from delta.tables import *
from pyspark.sql import DataFrame

# COMMAND ----------

env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils


# COMMAND ----------

def get_numero_tratado(value: str):
    valor = str(value).replace('-', '').replace('.', '').replace('/', '')
    return valor


get_numero_tratado_udf = F.udf(lambda value: get_numero_tratado(value))


def trata_caractere(value):
    return value.replace('-', '').replace('.', '')


trata_caractere_udf = F.udf(lambda value: trata_caractere(value))


def is_empty_or_blank(value: str):
    if not bool(value):
        return True
    value = value.strip()
    if ("" == value) | (" " == value):
        return True
    return False


def get_value_or_default(value: str, default_value: str):
    if is_empty_or_blank(value):
        return default_value
    return value.strip()


get_value_or_default_udf = F.udf(lambda value, default_value: get_value_or_default(value, default_value))


def retira_espacos(value: str):
    if value is not None:
        return value.strip()
    return value


retira_espacos_udf = F.udf(lambda value: retira_espacos(value))


def get_null():
    return None


get_null_udf = F.udf(lambda: get_null())


def explode_split(df: DataFrame, column: str, renamed_column: str):
    return df.withColumn(renamed_column, F.explode_outer(F.split(F.col(column), ';'))).dropDuplicates()


# COMMAND ----------

# DBTITLE 1,Carga em API_REDE_REFRD
api_rede_referenciada = [(1, 'capitalization-title', 'Capitalização', ''),
                         (2, 'person', 'Vida', '51990695000137'),
                         (3, 'pension-plan', 'Previdência Risco', ''),
                         (4, 'life-pension', 'Previdência Sobrevivência', ''),
                         (5, 'auto-insurance', 'Auto', '92682038000100'),
                         (6, 'home-insurance', 'RE - Residencial', '')]

schema = T.StructType([ \
    T.StructField("CAPI_REDE_REFRD", T.IntegerType(), True), \
    T.StructField("IEXTER_API_REDE_REFRD", T.StringType(), True), \
    T.StructField("IAPI_REDE_REFRD", T.StringType(), True), \
    T.StructField("cnpjSociedade", T.StringType(), True)
])

insert_api_rede_referenciada = spark.createDataFrame(data=api_rede_referenciada, schema=schema)

# Guarda o df de api com o cnpj das empresas
api_rede = insert_api_rede_referenciada

insert_api_rede_referenciada = insert_api_rede_referenciada \
    .drop('cnpjSociedade')

insert_api_rede_referenciada = insert_api_rede_referenciada \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

table = 'opincanais.API_REDE_REFRD'
display(insert_api_rede_referenciada)
write_db_sqlserver(dbutils, insert_api_rede_referenciada, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Lê Bronze
rede_referenciada_raw_read = read_delta_file(dbutils, spark, context.STORAGE_BRONZE_REDE_REFERENCIADA)

# COMMAND ----------

# DBTITLE 1,Upper no Endereço
#coloca todos os dados do endereço como maíusculo
rede_referenciada_raw = rede_referenciada_raw_read.withColumn('enderecoCompleto', F.upper(F.col('enderecoCompleto'))) \
                                            .withColumn('complemento', F.upper(F.col('complemento'))) \
                                            .withColumn('bairro', F.upper(F.col('bairro'))) \
                                            .withColumn('municipio', F.upper(F.col('municipio')))

# COMMAND ----------

# Retira bairro vazio
rede_referenciada_bronze = rede_referenciada_raw.filter("bairro is not null").filter("ddi is not null").filter(
    "ddd is not null")

# COMMAND ----------

# DBTITLE 1,Trata Campos
rede_referenciada_bronze = rede_referenciada_bronze \
    .withColumn('cnpjSociedade', get_numero_tratado_udf('cnpjSociedade')) \
    .withColumn('cnpjRedeReferenciada', get_numero_tratado_udf('cnpjRedeReferenciada')) \
    .withColumn('numeroTelefone', trata_caractere_udf('numeroTelefone')) \
    .withColumn('cep', get_numero_tratado_udf('cep')) \
    .withColumn('nomeRedeReferenciada', retira_espacos_udf('nomeRedeReferenciada')) \
    .withColumn('complemento', retira_espacos_udf('complemento'))

# COMMAND ----------

table = 'opincanais.CIA_OPEN_INSCE'
companhia_seguradora_load = read_db_sqlserver(dbutils, spark, table, context.SQLSERVER_URL_CANAIS,
                                              context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                                              context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)
companhia_seguradora = companhia_seguradora_load.select('CCIA_OPEN_INSCE', 'CCNPJ_CIA_OPIN')
companhia_seguradora = companhia_seguradora \
    .withColumnRenamed('CCIA_OPEN_INSCE', 'seqCompanhia') \
    .withColumnRenamed('CCNPJ_CIA_OPIN', 'cnpjSociedade')

# Preparando para carregar o codigo da Companhia
rede_referenciada_cia = rede_referenciada_bronze \
    .join(companhia_seguradora, ['cnpjSociedade'], 'left')

rede_referenciada_cia = rede_referenciada_cia \
    .drop('cnpjSociedade')

display(companhia_seguradora_load)

# COMMAND ----------

# DBTITLE 1,Grava Prestador (PRETR_REDE_REFRD_OPIN)
prestador_campos = rede_referenciada_cia.select('marca', 'seqCompanhia', 'nomeRedeReferenciada',
                                                'cnpjRedeReferenciada').distinct()

prestador_sequencial = prestador_campos.withColumn('seqPrestador',
                                                   row_number().over(Window.partitionBy('marca').orderBy('marca')))
prestador_sequencial = prestador_sequencial.drop('marca')

insert_prestador = prestador_sequencial \
    .withColumnRenamed('seqPrestador', 'CPRETR_REDE_REFRD') \
    .withColumnRenamed('seqCompanhia', 'CCIA_OPEN_INSCE') \
    .withColumnRenamed('nomeRedeReferenciada', 'IPRETR_REDE_REFRD') \
    .withColumnRenamed('cnpjRedeReferenciada', 'NCNPJ_PRETR_REDE_REFRD') \
    .withColumn('OREG_ATIVO', F.lit('S')) \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

prestador_reordenado = insert_prestador.select('CPRETR_REDE_REFRD', 'CCIA_OPEN_INSCE', 'IPRETR_REDE_REFRD',
                                               'NCNPJ_PRETR_REDE_REFRD', 'OREG_ATIVO', 'CUSUAR_MANUT_REG',
                                               'AULT_ATULZ_REG')

display(prestador_reordenado)

table = 'opincanais.PRETR_REDE_REFRD_OPIN'
write_db_sqlserver(dbutils, prestador_reordenado, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Grava Horário de Funcionamento (HORA_FUNCN_REDE_REFRD_OPIN)
rede_referenciada_bronze = explode_split(rede_referenciada_bronze, 'diasFuncionamento', 'CDIA_SMNAL_HORA_FUNCN')
rede_referenciada_bronze = explode_split(rede_referenciada_bronze, 'horarioEncerramento', 'RHORA_FCHTO_FUNCN')
rede_referenciada_bronze = explode_split(rede_referenciada_bronze, 'horarioAbertura', 'RHORA_ABERT_FUNCN')

rede_referenciada_horario_funcionamento = rede_referenciada_bronze \
    .withColumnRenamed('cnpjRedeReferenciada', 'NCNPJ_PRETR_REDE_REFRD') \
    .withColumn('CDIA_SMNAL_HORA_FUNCN', F.regexp_replace('CDIA_SMNAL_HORA_FUNCN', '_FEIRA', ''))

rede_referenciada_horario_funcionamento = rede_referenciada_horario_funcionamento. \
    select('NCNPJ_PRETR_REDE_REFRD', 'CDIA_SMNAL_HORA_FUNCN', 'RHORA_FCHTO_FUNCN', 'RHORA_ABERT_FUNCN')

rede_referenciada_horario_funcionamento = rede_referenciada_horario_funcionamento.where('CDIA_SMNAL_HORA_FUNCN is not null')
rede_referenciada_horario_funcionamento.display()

# COMMAND ----------

table = 'opincanais.PRETR_REDE_REFRD_OPIN'
prestador = read_db_sqlserver(dbutils, spark, table, context.SQLSERVER_URL_CANAIS, context.SQLSERVER_DATABASE_CANAIS,
                              context.SQLSERVER_DATABASE_CANAIS_USER, context.SQLSERVER_DATABASE_CANAIS_PWD,
                              context.SQLSERVER_DATABASE_PORT)

rede_referenciada_horario_funcionamento_join = prestador \
    .join(rede_referenciada_horario_funcionamento, ['NCNPJ_PRETR_REDE_REFRD'], "inner")

rede_referenciada_horario_funcionamento_join = rede_referenciada_horario_funcionamento_join. \
    select('CPRETR_REDE_REFRD', 'CDIA_SMNAL_HORA_FUNCN', 'RHORA_FCHTO_FUNCN', 'RHORA_ABERT_FUNCN')

rede_referenciada_horario_insert = rede_referenciada_horario_funcionamento_join \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

rede_referenciada_horario_insert = rede_referenciada_horario_insert.select('CPRETR_REDE_REFRD', 'CDIA_SMNAL_HORA_FUNCN',
                                                                           'RHORA_FCHTO_FUNCN', 'RHORA_ABERT_FUNCN',
                                                                           'CUSUAR_MANUT_REG',
                                                                           'AULT_ATULZ_REG').distinct()
display(rede_referenciada_horario_insert)

table = 'opincanais.HORA_FUNCN_REDE_REFRD_OPIN'
write_db_sqlserver(dbutils, rede_referenciada_horario_insert, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Join Seq Prestador
prestador_sequencial = prestador_sequencial \
    .drop('seqCompanhia') \
    .drop('nomeRedeReferenciada')

rede_referenciada_join = rede_referenciada_bronze \
    .join(prestador_sequencial, ['cnpjRedeReferenciada'], 'left')

# COMMAND ----------

# DBTITLE 1,Grava Endereço Prestador (ENDER_PRETR_REDE_REFRD)
rede_referenciada_endereco = rede_referenciada_join.select('seqPrestador', 'enderecoCompleto', 'complemento', 'bairro',
                                                           'municipio', 'codigoIbge', 'siglaUF', 'cep', 'pais',
                                                           'codigoPais', 'latitude', 'longitude', 'ddi', 'ddd',
                                                           'numeroTelefone').distinct()
rede_referenciada_sequencial = rede_referenciada_endereco.withColumn('seqEndereco', row_number().over(
    Window.partitionBy('seqPrestador').orderBy('seqPrestador')))

rede_referenciada_telefone = rede_referenciada_sequencial  # rede_referenciada_endereco

rede_referenciada_sequencial = rede_referenciada_sequencial \
    .drop('ddi') \
    .drop('ddd') \
    .drop('numeroTelefone')

rede_referenciada_endereco_insert = rede_referenciada_sequencial \
    .withColumnRenamed('seqPrestador', 'CPRETR_REDE_REFRD') \
    .withColumnRenamed('seqEndereco', 'CENDER_PRETR_REDE_REFRD') \
    .withColumnRenamed('enderecoCompleto', 'ELOGDR_PRETR_REDE_REFRD') \
    .withColumnRenamed('complemento', 'RCOMPL_ENDER_PRETR') \
    .withColumnRenamed('bairro', 'IBAIRO_ENDER_PRETR') \
    .withColumnRenamed('municipio', 'IMUN_ENDER_PRETR') \
    .withColumnRenamed('codigoIbge', 'CIBGE_MUN_PRETR') \
    .withColumnRenamed('siglaUF', 'SUF_ENDER_PRETR') \
    .withColumnRenamed('cep', 'CCEP_ENDER_PRETR') \
    .withColumnRenamed('pais', 'IPAIS_ENDER_PRETR') \
    .withColumnRenamed('codigoPais', 'CISO_PAIS_ENDER') \
    .withColumnRenamed('latitude', 'CLATIT_PRETR_REDE_REFRD') \
    .withColumnRenamed('longitude', 'CLONGT_PRETR_REDE_REFRD') \
    .withColumn('OACSDE_CLI_PRETR', F.lit('N')) \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('NENDER_PRETR_REDE_REFRD', get_null_udf()) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

endereco_rede_reordenado = rede_referenciada_endereco_insert.select('CPRETR_REDE_REFRD', 'CENDER_PRETR_REDE_REFRD',
                                                                    'ELOGDR_PRETR_REDE_REFRD',
                                                                    'NENDER_PRETR_REDE_REFRD', 'RCOMPL_ENDER_PRETR',
                                                                    'IBAIRO_ENDER_PRETR', 'IMUN_ENDER_PRETR',
                                                                    'CIBGE_MUN_PRETR', 'SUF_ENDER_PRETR',
                                                                    'CCEP_ENDER_PRETR', 'IPAIS_ENDER_PRETR',
                                                                    'CISO_PAIS_ENDER', 'CLATIT_PRETR_REDE_REFRD',
                                                                    'CLONGT_PRETR_REDE_REFRD', 'OACSDE_CLI_PRETR',
                                                                    'CUSUAR_MANUT_REG', 'AULT_ATULZ_REG')

display(endereco_rede_reordenado)

table = 'opincanais.ENDER_PRETR_REDE_REFRD'
write_db_sqlserver(dbutils, rede_referenciada_endereco_insert, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Grava Telefone Prestador (FONE_ENDER_PRETR)
### Levantar por que não foi modelado
# tipoTelefone

rede_referenciada_endereco = rede_referenciada_telefone.select('seqPrestador', 'seqEndereco', 'ddi', 'ddd',
                                                               'numeroTelefone').distinct()
rede_referenciada_sequencial = rede_referenciada_endereco.withColumn('seqTelefone', row_number().over(
    Window.partitionBy('seqPrestador').orderBy('seqPrestador')))

rede_referenciada_telefone_insert = rede_referenciada_sequencial \
    .withColumnRenamed('seqPrestador', 'CPRETR_REDE_REFRD') \
    .withColumnRenamed('seqEndereco', 'CENDER_PRETR_REDE_REFRD') \
    .withColumnRenamed('seqTelefone', 'CFONE_ENDER_PRETR') \
    .withColumnRenamed('ddi', 'CDDI_FONE_ENDER_PRETR') \
    .withColumnRenamed('ddd', 'CDDD_FONE_ENDER_PRETR') \
    .withColumnRenamed('numeroTelefone', 'NFONE_ENDER_PRETR') \
    .withColumn('OFONE_PRINC_PRETR', F.lit('S')) \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

telefone_rede_reordenado = rede_referenciada_telefone_insert.select('CPRETR_REDE_REFRD', 'CENDER_PRETR_REDE_REFRD',
                                                                    'CFONE_ENDER_PRETR', 'OFONE_PRINC_PRETR',
                                                                    'CDDI_FONE_ENDER_PRETR', 'CDDD_FONE_ENDER_PRETR',
                                                                    'NFONE_ENDER_PRETR', 'CUSUAR_MANUT_REG',
                                                                    'AULT_ATULZ_REG')

print(telefone_rede_reordenado.select('CPRETR_REDE_REFRD', 'CENDER_PRETR_REDE_REFRD', 'CFONE_ENDER_PRETR',
                                      'NFONE_ENDER_PRETR').count())

display(telefone_rede_reordenado.select('CPRETR_REDE_REFRD', 'CENDER_PRETR_REDE_REFRD', 'CFONE_ENDER_PRETR',
                                        'NFONE_ENDER_PRETR'))

table = 'opincanais.FONE_ENDER_PRETR'
write_db_sqlserver(dbutils, telefone_rede_reordenado, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Old Grava Produtos (PRODT_REDE_REFRD_OPIN) - Aqui
# Esta tabela será carregada via api, está neste script apenas para carga das demais tabelas

# Explode produtos do arquivo csv
# produto_explode = rede_referenciada_join.withColumn('codigoProdutoPrestador', F.explode(F.split('codigoProduto', ';')))
# display(produto_explode)

# Uni nome da api as produtos
# api_produtos = produto_explode \
#     .join(api_rede, ['cnpjSociedade'], 'left')

# display(api_produtos)
# seleciona produtos
# api_produtos_select = api_produtos.select('marca', 'CAPI_REDE_REFRD', 'codigoProdutoPrestador').distinct()
# api_produtos_sequencial = api_produtos_select.withColumn('seqProduto', row_number().over(Window.partitionBy('marca').orderBy('marca')))

# api_produtos_sequencial = api_produtos_sequencial \
#     .withColumnRenamed('seqProduto', 'CPRODT_REDE_REFRD_OPIN') \
#     .withColumnRenamed('codigoProdutoPrestador', 'CEXTER_PRODT_COMCD') \
#     .withColumn('IPRODT_REDE_REFRD_OPIN', F.col('CPRODT_REDE_REFRD_OPIN')) \
#     .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
#     .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp())) \
#     .drop('marca')

# display(api_produtos_sequencial)
# table = 'PRODT_REDE_REFRD_OPIN'
# write_db_sqlserver(dbutils, api_produtos_sequencial, table)

# COMMAND ----------

# DBTITLE 1,Grava Produtos (PRODT_REDE_REFRD_OPIN) - novo
produtos_rede_referenciada_dados = [
    (1, 5, 1762, 'Bradesco Seguro Auto', 'carga'),
    (2, 5, 1774, 'Bradesco Seguro Auto Lar Caminhão', 'carga'),
    (3, 5, 1776, 'Bradesco Seguro Auto Lar', 'carga'),
    (4, 5, 1777, 'Bradesco Seguro Auto Assistência Total', 'carga'),
    (5, 5, 1771, 'Bradesco Seguro Auto Frota', 'carga'),
    (6, 5, 1930, 'Bradesco Seguro Auto Light Rede Referenciada', 'carga'),
    (7, 5, 1583, 'Bradesco Seguro Auto Classic', 'carga'),
    (8, 5, 1584, 'Bradesco Seguro Auto Exclusive', 'carga'),
    (9, 5, 1585, 'Bradesco Seguro Auto Prime', 'carga')]

schema = T.StructType([ \
    T.StructField("CPRODT_REDE_REFRD_OPIN", T.IntegerType(), True), \
    T.StructField("CAPI_REDE_REFRD", T.IntegerType(), True), \
    T.StructField("CEXTER_PRODT_COMCD", T.IntegerType(), True), \
    T.StructField("IPRODT_REDE_REFRD_OPIN", T.StringType(), True), \
    T.StructField("CUSUAR_MANUT_REG", T.StringType(), True)
])

insert_produtos_rede_referenciada = spark.createDataFrame(data=produtos_rede_referenciada_dados, schema=schema)

insert_produtos_rede_referenciada = insert_produtos_rede_referenciada.withColumn('AULT_ATULZ_REG',
                                                                                 F.to_timestamp(current_timestamp()))

display(insert_produtos_rede_referenciada)

table = 'opincanais.PRODT_REDE_REFRD_OPIN'
write_db_sqlserver(dbutils, insert_produtos_rede_referenciada, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Grava Produto Rede Referenciada (PRODT_PRETR_REDE_REFRD) - old
# Carrega produtos SQL SERVER
# table = 'PRODT_REDE_REFRD_OPIN'
# produtos = read_db_sqlserver(dbutils, spark,table)
# produtos_select = produtos.select('CPRODT_REDE_REFRD_OPIN', 'CEXTER_PRODT_COMCD' )
# produtos_sql_server = produtos_select.withColumnRenamed('CEXTER_PRODT_COMCD', 'codigoProdutoPrestador')

# Unifica produdos do arquivo com os produtos do sql server
# produtos_rede_referenciada = produto_explode \
#     .join(produtos_sql_server, ['codigoProdutoPrestador'], 'left')


# produtos_rede = produtos_rede_referenciada.select('seqPrestador', 'CPRODT_REDE_REFRD_OPIN').distinct()
# produtos_rede = produtos_rede.withColumnRenamed('seqPrestador', 'CPRETR_REDE_REFRD')

# produtos_rede_insert = produtos_rede \
#     .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
#     .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

# display(produtos_rede_insert)
# table = 'PRODT_PRETR_REDE_REFRD'
# write_db_sqlserver(dbutils, produtos_rede_insert, table)

# COMMAND ----------

# DBTITLE 1,Grava Produto Rede Referenciada (PRODT_PRETR_REDE_REFRD) - novo
# Carrega produtos SQL SERVER
table = 'opincanais.PRODT_REDE_REFRD_OPIN'
produtos = read_db_sqlserver(dbutils, spark, table, context.SQLSERVER_URL_CANAIS, context.SQLSERVER_DATABASE_CANAIS,
                             context.SQLSERVER_DATABASE_CANAIS_USER, context.SQLSERVER_DATABASE_CANAIS_PWD,
                             context.SQLSERVER_DATABASE_PORT)
produtos_select = produtos.select('CPRODT_REDE_REFRD_OPIN', 'CEXTER_PRODT_COMCD')
produtos_sql_server = produtos_select.withColumnRenamed('CEXTER_PRODT_COMCD', 'codigoProdutoPrestador')

# Explode produtos do arquivo csv
produto_explode = rede_referenciada_join \
    .withColumn('codigoProdutoPrestador', F.explode(F.split('codigoProduto', ';')))
produto_explode = produto_explode.where('codigoProduto <> "NA"')

# Unifica produdos do arquivo com os produtos do sql server
produtos_prestador_rede_referenciada_join = produto_explode \
    .join(produtos_sql_server, ['codigoProdutoPrestador'], 'left')

produtos_prestador_rede_referenciada_insert = produtos_prestador_rede_referenciada_join.select('codigoProdutoPrestador',
                                                                                               'seqPrestador').distinct()

produtos_prestador_rede_referenciada_insert = produtos_prestador_rede_referenciada_insert \
    .withColumnRenamed('seqPrestador', 'CPRETR_REDE_REFRD') \
    .withColumnRenamed('codigoProdutoPrestador', 'CPRODT_REDE_REFRD_OPIN') \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

produtos_prestador_rede_referenciada_insert = produtos_prestador_rede_referenciada_insert.where(
    'CPRODT_REDE_REFRD_OPIN <> "NA"')
# produtos_prestador_rede_referenciada_insert.select(F.col('CPRODT_REDE_REFRD_OPIN').cast('int').alias('CPRODT_REDE_REFRD_OPIN'))
display(produtos_prestador_rede_referenciada_insert)

table = 'opincanais.PRODT_PRETR_REDE_REFRD'
write_db_sqlserver(dbutils, produtos_prestador_rede_referenciada_insert, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Grava Tipo de Serviço (TPO_SERVC_OPIN)
tipo_servico = rede_referenciada_bronze.select('marca', 'tipoServicos').distinct()
tipo_servico = tipo_servico.withColumn('tipoServicos', F.explode(F.split('tipoServicos', ';')))
tipo_servico = tipo_servico.withColumn('tipoServicos', F.trim(F.col('tipoServicos'))).dropDuplicates()

tipo_servico_sequencial = tipo_servico.withColumn('seqTipoServico',
                                                  row_number().over(Window.partitionBy('marca').orderBy('marca')))

tipo_servico_sequencial = tipo_servico_sequencial \
    .withColumnRenamed('seqTipoServico', 'CTPO_SERVC_OPIN') \
    .withColumnRenamed('tipoServicos', 'ITPO_SERVC_OPIN') \
    .withColumn('OREG_ATIVO', F.lit('S')) \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp())) \
    .drop('marca')

display(tipo_servico_sequencial)

table = 'opincanais.TPO_SERVC_OPIN'
write_db_sqlserver(dbutils, tipo_servico_sequencial, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Grava Serviço (SERVC_REDE_REFRD_OPIN)
# Explode produtos do arquivo csv
servico_explode = rede_referenciada_join.withColumn('nomeServico', F.explode(F.split('nomesServicosPrestados', ';')))
servico_explode = servico_explode.withColumn('nomeServico', F.trim(F.col('nomeServico')))
servico = servico_explode.select('marca', 'nomeServico').distinct()
servico_sequencial = servico.withColumn('seqServico', row_number().over(Window.partitionBy('marca').orderBy('marca')))

servico_sequencial = servico_sequencial \
    .withColumnRenamed('seqServico', 'CSERVC_REDE_REFRD_OPIN') \
    .withColumnRenamed('nomeServico', 'ISERVC_REDE_REFRD_OPIN') \
    .withColumn('OREG_ATIVO', F.lit('S')) \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp())) \
    .drop('marca')

display(servico_sequencial)

table = 'opincanais.SERVC_REDE_REFRD_OPIN'
write_db_sqlserver(dbutils, servico_sequencial, table, context.SQLSERVER_URL_CANAIS, context.SQLSERVER_DATABASE_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS_USER, context.SQLSERVER_DATABASE_CANAIS_PWD,
                   context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Grava Serviço, Prestador e Tipo de Serviço (SERVC_PRETR_REDE_REFRD)
tipo_servico_sequencial = tipo_servico_sequencial \
    .withColumnRenamed('ITPO_SERVC_OPIN', 'tipoServicos') \
    .drop('OREG_ATIVO') \
    .drop('CUSUAR_MANUT_REG') \
    .drop('AULT_ATULZ_REG')

servico_sequencial = servico_sequencial \
    .withColumnRenamed('ISERVC_REDE_REFRD_OPIN', 'nomesServicosPrestados') \
    .drop('OREG_ATIVO') \
    .drop('CUSUAR_MANUT_REG') \
    .drop('AULT_ATULZ_REG')

# join com tipo de serviço
tipo_servico_explode = rede_referenciada_join \
    .withColumn('tipoServicos', F.explode(F.split('tipoServicos', ';')))
tipo_servico_explode = tipo_servico_explode \
    .withColumn('tipoServicos', F.trim(F.col('tipoServicos'))).dropDuplicates()
rede_referenciada_tipo_servico = tipo_servico_explode \
    .join(tipo_servico_sequencial, ['tipoServicos'], "left")

# join com Serviços
servico_explode = rede_referenciada_tipo_servico \
    .withColumn('nomesServicosPrestados', F.explode(F.split('nomesServicosPrestados', ';')))
servico_explode = servico_explode \
    .withColumn('nomesServicosPrestados', F.trim(F.col('nomesServicosPrestados'))).dropDuplicates()
rede_referenciada_servico_join = servico_explode \
    .join(servico_sequencial, ['nomesServicosPrestados'], "left")

rede_referenciada_servico_join = rede_referenciada_servico_join \
    .withColumn('descricaoTipoServicos', F.substring(F.col('descricaoTipoServicos'), 1, 1000))

servico_rede_referenciada = rede_referenciada_servico_join.select('seqPrestador', 'CTPO_SERVC_OPIN',
                                                                  'CSERVC_REDE_REFRD_OPIN',
                                                                  'descricaoTipoServicos').distinct()

servico_rede_referenciada = servico_rede_referenciada \
    .withColumnRenamed('seqPrestador', 'CPRETR_REDE_REFRD') \
    .withColumnRenamed('descricaoTipoServicos', 'RSERVC_PRETR_REDE_REFRD') \
    .withColumn('CUSUAR_MANUT_REG', F.lit('carga')) \
    .withColumn('AULT_ATULZ_REG', F.to_timestamp(current_timestamp()))

display(servico_rede_referenciada)

table = 'opincanais.SERVC_PRETR_REDE_REFRD'
write_db_sqlserver(dbutils, servico_rede_referenciada, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

# COMMAND ----------

# DBTITLE 1,Grava Cobertura (COBER_PRODT_REDE_REFRD)
coberturas_rede_referenciada = read_delta_file(dbutils, spark, context.STORAGE_BRONZE_REDE_REFERENCIADA_COBERTURAS)

insert_coberturas_rede_referenciada = coberturas_rede_referenciada.select(
    F.col('CCOBER_PRODT_REDE_REFRD').cast('int').alias('CCOBER_PRODT_REDE_REFRD'),
    F.col('CPRODT_REDE_REFRD_OPIN').cast('int').alias('CPRODT_REDE_REFRD_OPIN'),
    F.col('RDETLH_COBER_PRODT_REDE_OPIN'),
    F.lit('carga').alias('CUSUAR_MANUT_REG'),
    F.to_timestamp(current_timestamp()).alias('AULT_ATULZ_REG')
)

display(insert_coberturas_rede_referenciada)

table = 'opincanais.COBER_PRODT_REDE_REFRD'
write_db_sqlserver(dbutils, insert_coberturas_rede_referenciada, table, context.SQLSERVER_URL_CANAIS,
                   context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER,
                   context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)

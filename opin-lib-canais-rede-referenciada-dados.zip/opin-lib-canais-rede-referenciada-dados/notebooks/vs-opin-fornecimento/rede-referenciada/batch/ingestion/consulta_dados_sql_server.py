# COMMAND ----------
import os
if os.getenv("AMBIENTE") != 'LOCAL_WIN' and os.getenv("AMBIENTE") != 'LOCAL_LINUX':
    os.system("pip install /dbfs/FileStore/jars/commons/jproperties-2.1.1-py2.py3-none-any.whl")
    os.system("pip install /dbfs/FileStore/jars/commons/pymongo-4.0.1-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl")
    os.system("pip install /dbfs/FileStore/jars/vs-opin-fornecimento/opin-lib-canais-rede-referenciada-dados/opin_lib_canais_rede_referenciada_dados-1.0.3-py3-none-any.whl")

# COMMAND ----------

from opin_lib_canais_rede_referenciada_dados.config.context import Context
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.storage_functions import read_db_sqlserver

# COMMAND ----------

# context = Context(dbutils, spark)

env = Environment()
if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
    dbutils = None
    spark = None

context = Context(spark, env, dbutils)
spark = context.spark
dbutils = context.dbutils

# COMMAND ----------

tables = ['opincanais.API_REDE_REFRD','opincanais.PRODT_REDE_REFRD_OPIN', \
          'opincanais.COBER_PRODT_REDE_REFRD', 'opincanais.CIA_OPEN_INSCE','opincanais.PRETR_REDE_REFRD_OPIN', \
          'opincanais.ENDER_PRETR_REDE_REFRD','opincanais.FONE_ENDER_PRETR', \
          'opincanais.HORA_FUNCN_REDE_REFRD_OPIN', 'opincanais.PRODT_PRETR_REDE_REFRD','opincanais.TPO_SERVC_OPIN', \
          'opincanais.SERVC_PRETR_REDE_REFRD','opincanais.SERVC_REDE_REFRD_OPIN']

print('***** Rede Referenciada *****')
for table in tables:
    print(table)
    df = read_db_sqlserver(dbutils, spark, table, context.SQLSERVER_URL_CANAIS, context.SQLSERVER_DATABASE_CANAIS, context.SQLSERVER_DATABASE_CANAIS_USER, context.SQLSERVER_DATABASE_CANAIS_PWD, context.SQLSERVER_DATABASE_PORT)
    display(df)


#!/usr/bin/env bash

# This file is the entrypoint of the image
# It must be executed as an unprivileged user

# Fail on error
chmod 755 ./scripts/create_quality_profile_and_quality_gate_sonar.bash

exec ./scripts/create_quality_profile_and_quality_gate_sonar.bash &
exec ./bin/run.sh

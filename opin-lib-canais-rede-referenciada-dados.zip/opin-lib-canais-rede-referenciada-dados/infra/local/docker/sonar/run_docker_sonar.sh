#!/bin/bash

case "$1" in
  --build)

    mkdir -p /data/sonarqube/conf
    mkdir -p /data/sonarqube/data
    mkdir -p /data/sonarqube/lib/bundled-plugins
    mkdir -p /data/sonarqube/scripts

    sudo docker-compose -f docker-compose.yml up -d --build
    shift
    ;;
  --start)
    sudo docker-compose -f docker-compose.yml up -d
    shift
    ;;
  --stop-all)
    sudo docker stop $(sudo docker ps -q)
    shift
    ;;
  --stop)
    sudo docker stop $(sudo docker ps -f name=sonarqube-opin)
    shift
    ;;
  --info)
    sudo docker ps -f name=sonarqube-opin
    shift
    ;;
  *) echo "Opcao invalida ou nao informada: $1" ;;
esac
#!/usr/bin/env bash

case "$1" in
  --build)

    mkdir -p /data/mongodb

    sudo docker-compose -f docker-compose.yml up -d --build
    shift
    ;;
  --start)
    sudo docker-compose -f docker-compose.yml up -d
    shift
    ;;
  --stop-all)
    sudo docker stop $(sudo docker ps -q)
    shift
    ;;
  --stop)
    sudo docker stop $(sudo docker ps -f name=mongodb-opin -f name=mongo-express-opin)
    shift
    ;;
  --info)
    sudo docker ps -f name=mongodb-opin -f name=mongo-express-opin
    shift
    ;;
  *) echo "Opcao invalida ou nao informada: $1" ;;
esac
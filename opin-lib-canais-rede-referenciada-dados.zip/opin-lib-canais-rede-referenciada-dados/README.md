# Introdução 
Projeto de ingestão, transformação e persistência no Cosmos DB (Mongodb API) de dados cadastrais de Rede Referenciada do Bradesco Seguros para uso nas APIs de fornecimento do Open Insurance.

Os dados são coletados de arquivos ".csv" recebidos através de file server disponibilizado pelo Bradesco Seguros.

Na coleta de todos os dados citados é realizada a ingestão em formato ".parquet" dentro do Azure Data Lake Storage V2. Com os dados ingeridos no Data Lake é realizada a transformação dos dados para adequar as necessidades do regulatório da SUSEP/CNSeg e realizar a carga no Banco de Dados.

O Data Lake segue a arquitetura do Databricks Lakehouse que consiste no uso do formato "Delta" e das camadas Bronze (Dados Brutos), Silver (Dados Transformados) e Gold (Dados Refinados).

Em todo o processo são utilizados o Azure Databricks (Python / PySpark) para desenvolvimento das transformações e carga no banco de dados e o Azure Data Factory para ingestão e orquestração da pipeline de dados. 

# Configuração

Para realizar a configuração do projeto, siga os passos abaixo:

1. Clone do repositório
2. Instalação do Python >= 3.8.5
3. Instalação dos pacotes presentes no requirements.txt
4. Instalação da engine do Docker
5. Inicialização de containers a partir do docker-compose.yml presente no diretório: infra/local/docker/mongodb
6. Para verificar o funcionamento do banco de dados, deve acessar o link http://localhost:30000 através do browser. Esse link levará até o portal do mongo-express (ferramenta de administração web do Atlas MongoDB)

# Build

Para realizar a build da biblioteca Python, siga os passos abaixo:

1. Executar o script build.sh presente na raiz do projeto através de terminal Bash;
2. Ou, Executar um dos comandos a seguir: 
   * `python setup.py bdist_wheel`
   * `python3 setup.py bdist_wheel`

# Teste

Para executar os testes unitários do projeto, siga os passos abaixo:

1. Dentro do pycharm, abra o projeto;
2. Com o botão direito do mouse, clique na pasta test;
3. Depois, clique em Run "Pytest in test".

# Contribuição

Para os desenvolvedores que realizarem alterações no código:

1. Tentem sempre seguir o padrão definido pela convenção do PEP8;
2. Sempre criem Enums para constantes, afim de deixar o código mais limpo;
3. Mantenham cada função com apenas uma ação, sempre que possível;
4. Mantenham o código limpo, sem comentários desnecessários. As classes, métodos e funções, devem ser auto explicativas.

from delta.tables import DeltaTable


def purge(spark, path: str):
    delta_table = DeltaTable.forPath(spark, path)
    delta_table.vacuum()
        
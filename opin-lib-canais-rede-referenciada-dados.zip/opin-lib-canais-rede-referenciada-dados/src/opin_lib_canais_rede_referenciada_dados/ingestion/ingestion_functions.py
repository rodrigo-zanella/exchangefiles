from pyspark.sql.session import SparkSession
from opin_lib_canais_rede_referenciada_dados.storage_functions import \
    read_text_file, is_empty, write_delta_file, delete, OVERWRITE, read_db_sqlserver
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from pyspark.shell import sqlContext


def ingestion(dbutils, spark: SparkSession, input_path: str,
              output_path: str, file_format: str, has_header: bool,
              infer_schema: bool, delimiter: str, env: Environment):

    if not is_empty(dbutils, input_path):
        data = read_text_file(dbutils, spark, file_format, has_header, infer_schema,
                              delimiter, input_path)
        write_delta_file(data, output_path, OVERWRITE)
        delete(dbutils, input_path, env)


def get_sql_server_script(script, output_path: str):
    df = sqlContext.sql(script)

    if df.count() > 0:
        write_delta_file(df, output_path, OVERWRITE)


def create_view_sql(spark, dbutils, url, port, database, table_name, user, password):
    df = read_db_sqlserver(dbutils, spark, table_name, url, database, user, password, port)
    table_view = table_name.replace('opincanais.', '')
    df.createOrReplaceTempView(table_view)


def ingestion_from_sql_server(dbutils, spark, output_path, url, database, user, password, port):
    tables = ['opincanais.CIA_OPEN_INSCE',
              'opincanais.API_REDE_REFRD',
              'opincanais.PRETR_REDE_REFRD_OPIN',
              'opincanais.PRODT_REDE_REFRD_OPIN',
              'opincanais.TPO_SERVC_OPIN',
              'opincanais.SERVC_REDE_REFRD_OPIN',
              'opincanais.ENDER_PRETR_REDE_REFRD',
              'opincanais.PRODT_PRETR_REDE_REFRD',
              'opincanais.SERVC_PRETR_REDE_REFRD',
              'opincanais.FONE_ENDER_PRETR',
              'opincanais.HORA_FUNCN_REDE_REFRD_OPIN',
              'opincanais.COBER_PRODT_REDE_REFRD'
              ]

    for table_name in tables:
        create_view_sql(spark, dbutils, url, port, database, table_name, user, password)

    # refazer o select abaixo conforme o negócio
    script = "SELECT \
                  CS.IMARCA_CIA_OPIN AS marca, \
                  CS.ICIA_OPIN AS nomeSociedade, \
                  CAST(CS.CCNPJ_CIA_OPIN AS STRING) AS cnpjSociedade, \
                  IPRETR_REDE_REFRD AS nomeRedeReferenciada, \
                  NCNPJ_PRETR_REDE_REFRD AS cnpjRedeReferenciada, \
                  PO.CEXTER_PRODT_COMCD AS codigoProduto, \
                  PO.IPRODT_REDE_REFRD_OPIN AS nomeProduto, \
                  CO.RDETLH_COBER_PRODT_REDE_OPIN AS nomeCobertura, \
                  EN.ELOGDR_PRETR_REDE_REFRD AS enderecoCompleto, \
                  EN.RCOMPL_ENDER_PRETR AS complemento, \
                  EN.IBAIRO_ENDER_PRETR AS bairro, \
                  EN.IMUN_ENDER_PRETR AS municipio, \
                  EN.SUF_ENDER_PRETR AS siglaUF, \
                  CAST(EN.CIBGE_MUN_PRETR AS STRING) AS codigoIbge, \
                  CAST(EN.CCEP_ENDER_PRETR AS STRING) AS cep, \
                  EN.IPAIS_ENDER_PRETR AS pais, \
                  EN.CISO_PAIS_ENDER AS codigoPais, \
                  CAST(EN.CLATIT_PRETR_REDE_REFRD AS STRING) AS latitude, \
                  CAST(EN.CLONGT_PRETR_REDE_REFRD AS STRING) AS longitude, \
                  HR.RHORA_ABERT_FUNCN AS horarioAbertura, \
                  HR.RHORA_FCHTO_FUNCN AS horarioEncerramento, \
                  HR.CDIA_SMNAL_HORA_FUNCN AS diasFuncionamento, \
                  EN.OACSDE_CLI_PRETR AS indicadorRestricaoAcesso, \
                  '' AS tipoTelefone, \
                  CAST(TL.CDDI_FONE_ENDER_PRETR AS STRING) AS ddi, \
                  CAST(TL.CDDD_FONE_ENDER_PRETR AS STRING) AS ddd, \
                  CAST(TL.NFONE_ENDER_PRETR AS STRING) AS numeroTelefone, \
                  TP.ITPO_SERVC_OPIN AS tipoServicos, \
                  '' AS tipoServicosOutros, \
                  SR.ISERVC_REDE_REFRD_OPIN AS nomesServicosPrestados, \
                  SV.RSERVC_PRETR_REDE_REFRD AS descricaoTipoServicos \
                  FROM \
                 PRETR_REDE_REFRD_OPIN PR \
                  INNER JOIN CIA_OPEN_INSCE CS ON \
                    PR.CCIA_OPEN_INSCE = CS.CCIA_OPEN_INSCE AND OREG_ATIVO = 'S' \
                  INNER JOIN PRODT_PRETR_REDE_REFRD PP ON \
                    PR.CPRETR_REDE_REFRD = PP.CPRETR_REDE_REFRD \
                  INNER JOIN PRODT_REDE_REFRD_OPIN PO ON \
                    PO.CEXTER_PRODT_COMCD = PP.CPRODT_REDE_REFRD_OPIN \
                  INNER JOIN ENDER_PRETR_REDE_REFRD EN ON \
                    EN.CPRETR_REDE_REFRD = PR.CPRETR_REDE_REFRD \
                  INNER JOIN FONE_ENDER_PRETR TL ON \
                    TL.CPRETR_REDE_REFRD = PR.CPRETR_REDE_REFRD  and \
                    TL.CENDER_PRETR_REDE_REFRD = EN.CENDER_PRETR_REDE_REFRD \
                  INNER JOIN SERVC_PRETR_REDE_REFRD SV ON \
                    SV.CPRETR_REDE_REFRD = PR.CPRETR_REDE_REFRD \
                  INNER JOIN TPO_SERVC_OPIN TP ON \
                    TP.CTPO_SERVC_OPIN = SV.CTPO_SERVC_OPIN  \
                  INNER JOIN SERVC_REDE_REFRD_OPIN SR ON \
                    SR.CSERVC_REDE_REFRD_OPIN = SV.CSERVC_REDE_REFRD_OPIN \
                  INNER JOIN HORA_FUNCN_REDE_REFRD_OPIN HR ON \
                    PR.CPRETR_REDE_REFRD = HR.CPRETR_REDE_REFRD \
                  INNER JOIN COBER_PRODT_REDE_REFRD CO ON \
                    PO.CEXTER_PRODT_COMCD = CO.CPRODT_REDE_REFRD_OPIN \
                  order BY 	\
                    CS.IMARCA_CIA_OPIN, \
                  CS.ICIA_OPIN, \
                  CAST(CS.CCNPJ_CIA_OPIN AS STRING), \
                  IPRETR_REDE_REFRD , \
                  NCNPJ_PRETR_REDE_REFRD , \
                  PO.CEXTER_PRODT_COMCD , \
                  PO.IPRODT_REDE_REFRD_OPIN  "

    get_sql_server_script(script, output_path)

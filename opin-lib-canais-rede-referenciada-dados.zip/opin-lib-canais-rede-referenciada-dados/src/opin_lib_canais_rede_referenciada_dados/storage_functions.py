from pyspark.sql import SparkSession
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType
from pymongo import MongoClient
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum

OVERWRITE = 'overwrite'


def get_files(dbutils, path):
    return dbutils.fs_ls(path)


def is_empty(dbutils, path: str):
    try:
        files = get_files(dbutils, path)
        return 0 == len(files)
    except Exception:
        return True


def delete(dbutils, path: str, env: Environment):
    if is_empty(dbutils, path): 
        return
    files = get_files(dbutils, path)
    if 0 == len(files):    
        return
    if env.env_current in (EnvironmentEnum.LOCAL_LINUX, EnvironmentEnum.LOCAL_WIN):
        for file in files:
            dbutils.fs_rm(f"{path}/{file}", True)
    else:
        for file in files:
            dbutils.fs_rm(file.path, True)


def read_json_file(dbutils, spark: SparkSession, path: str):
    if not is_empty(dbutils, path):
        data = spark.read.format('json').load(path)
        return data


def read_text_file(dbutils, spark: SparkSession, file_format: str, has_header: bool,
                   infer_schema: bool, delimiter: str, path: str):
    if not is_empty(dbutils, path):
        data = spark.read.format(file_format) \
            .option('header', has_header) \
            .option('inferSchema', infer_schema) \
            .option('sep', delimiter) \
            .load(path)

        return data


def read_text_file_from_schema(dbutils, spark: SparkSession, file_format: str, schema: StructType,
                   delimiter: str, path: str):
    if not is_empty(dbutils, path):
        data = spark.read.format(file_format) \
            .option('header', False) \
            .option('schema', schema) \
            .option('sep', delimiter) \
            .load(path)

        return data


def read_delta_file(dbutils, spark: SparkSession, path: str):
    if not is_empty(dbutils, path):
        return spark.read \
            .format('delta') \
            .option('inferSchema', 'true') \
            .load(path)


def read_delta_file_or_return_empty(dbutils, spark: SparkSession, path: str, schema):
    if not is_empty(dbutils, path):
        return spark.read \
            .format('delta') \
            .option('inferSchema', 'true') \
            .load(path)
    else:
        return spark.createDataFrame([], schema)


def write_delta_file(data: DataFrame, path: str, mode: str):
    data.write \
        .format('delta') \
        .option("overwriteSchema", "true") \
        .save(path, mode=mode)


def upsert_cosmosdb(data: DataFrame, uri: str, database: str, collection: str, keys: str):
    data.write \
        .option("uri", uri) \
        .option("database", database) \
        .option("collection", collection) \
        .option("replaceDocument", "true") \
        .option('shardKey', f"{keys}") \
        .mode('append') \
        .format("com.mongodb.spark.sql") \
        .save()


def delete_cosmosdb(deleted_dataframe, uri, database, collection, key_silver, key_db):
    client = MongoClient(uri)
    db = client[database]
    db_collection = db[collection]

    rows_to_delete = [row[0] for row in deleted_dataframe.select(key_silver).distinct().collect()]
    if 0 < len(rows_to_delete):
        db_collection.delete_many({f"{key_db}": {"$in": rows_to_delete}})


def read_db_sqlserver(dbutils, spark, table: str, url: str, database: str, user: str, password: str, port: str):

    # Carrega dados da tabela do SQL Server
    data = spark.read.format("jdbc") \
        .option("url", f"jdbc:sqlserver://{url}:{port};databaseName={database}") \
        .option("dbtable", table) \
        .option("user", user) \
        .option("password", password) \
        .option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').load()
    return data


def write_db_sqlserver(dbutils, data, table: str, url: str, database: str, user: str, password: str, port: str):

    data.write.format("jdbc") \
                     .option("url", f"jdbc:sqlserver://{url}:{port};databaseName={database}") \
                     .option("dbtable", table) \
                     .option("user", user) \
                     .option("password", password) \
                     .option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').mode('append').save()

from pyspark.sql import SparkSession

from opin_lib_canais_rede_referenciada_dados.config.util.dbutils.dbutils_helper import DBUtilsHelper
from opin_lib_canais_rede_referenciada_dados.config.util.logger import Logger
from opin_lib_canais_rede_referenciada_dados.config.configuration import Configuration
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment
from opin_lib_canais_rede_referenciada_dados.config.util.environment_enum import EnvironmentEnum
from opin_lib_canais_rede_referenciada_dados.config.util.spark.app_spark_context_helper import SparkContextHelper


class Context:
    """
    O objetivo dessa classe Context é iniciar o contexto da aplicação de acordo
    com o ambiente em que é executado. Logo, torna-se um ponto comum para
    acesso a recursos externos e específicos de cada ambiente.
    """

    _LOG = Logger(path=__name__, name=__qualname__)
    _LOG.info("Initializing application context.")

    EMPTY = ''
    COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA = EMPTY
    COSMOSDB_DATABASE_CANAIS = EMPTY
    COSMOSDB_URI_CANAIS = EMPTY

    SQLSERVER_DATABASE_CANAIS = EMPTY
    SQLSERVER_DATABASE_CANAIS_PWD = EMPTY
    SQLSERVER_URL_CANAIS = EMPTY
    SQLSERVER_DATABASE_CANAIS_USER = EMPTY
    SQLSERVER_DATABASE_PORT = EMPTY

    STORAGE_MOUNT_PATH = EMPTY

    STORAGE_MOUNT_TRANSIENT = EMPTY
    STORAGE_TRANSIENT_REDE_REFERENCIADA = EMPTY
    STORAGE_TRANSIENT_REDE_REFERENCIADA_COBERTURAS = EMPTY

    STORAGE_MOUNT_BRONZE = EMPTY
    STORAGE_BRONZE_REDE_REFERENCIADA = EMPTY
    STORAGE_BRONZE_REDE_REFERENCIADA_COBERTURAS = EMPTY

    STORAGE_MOUNT_SILVER = EMPTY
    STORAGE_SILVER_REDE_REFERENCIADA = EMPTY
    STORAGE_SILVER_REDE_REFERENCIADA_INVALIDOS = EMPTY
    STORAGE_SILVER_REDE_REFERENCIADA_DELETADOS = EMPTY

    STORAGE_MOUNT_GOLD = EMPTY
    STORAGE_GOLD_REDE_REFERENCIADA = EMPTY

    def __init__(self, spark: SparkSession, env: Environment, dbutils):
        self.env = env
        self.config = Configuration(self.env)
        self.dbutils = DBUtilsHelper().get_instance(self.env, self.config, dbutils)
        self.spark = SparkContextHelper().get_instance(self.env, self.config, spark, self.dbutils)

        self._LOG.info("Default configuration: {0}".format(self.env.env_default.value))
        self._LOG.info("Current configuration: {0}".format(self.env.env_current.value))
        self._LOG.info("PySpark Version: {0} ".format(self.spark.version))

        self.load_properties()

    def load_properties(self):

        # COSMOSDB
        self.COSMOSDB_COLLECTION_CANAIS_REDE_REFERENCIADA = self.config.get("cosmosdb.collection.canais.redereferenciada")
        self.COSMOSDB_DATABASE_CANAIS = self.config.get("cosmosdb.database.canais.redereferenciada")
        self.COSMOSDB_URI_CANAIS = self.dbutils.get_kvault('cosmosdb.uri.canais')

        if self.env.env_current in (EnvironmentEnum.LOCAL_WIN, EnvironmentEnum.LOCAL_LINUX):
            self.SQLSERVER_DATABASE_CANAIS = self.config.get('sqlserver.database.canais')
            self.SQLSERVER_DATABASE_CANAIS_PWD = self.config.get('sqlserver.database.canais.pwd')
            self.SQLSERVER_URL_CANAIS = self.config.get('sqlserver.database.canais.url')
        else:
            self.SQLSERVER_DATABASE_CANAIS = self.dbutils.get_database_sql(self.env)
            self.SQLSERVER_DATABASE_CANAIS_PWD = self.dbutils.get_kvault('sqlserver.database.canais.pwd')
            self.SQLSERVER_URL_CANAIS = self.dbutils.get_url_sql(self.env)

        self.SQLSERVER_DATABASE_CANAIS_USER = self.config.get('sqlserver.database.canais.user')

        self.SQLSERVER_DATABASE_PORT = self.config.get('sqlserver.database.port')

        self.STORAGE_MOUNT_PATH = self.config.get("storage.mount.path")

        # STORAGE TRANSIENT
        self.STORAGE_MOUNT_TRANSIENT = f"{self.STORAGE_MOUNT_PATH}{self.config.get('storage.container.name.transient')}"
        self.STORAGE_TRANSIENT_REDE_REFERENCIADA = f"{self.STORAGE_MOUNT_TRANSIENT}{self.config.get('storage.path.canais.redereferenciada')}"
        self.STORAGE_TRANSIENT_REDE_REFERENCIADA_COBERTURAS = f"{self.STORAGE_MOUNT_TRANSIENT}{self.config.get('storage.path.canais.redereferenciada.coberturas')}"

        # STORAGE BRONZE
        self.STORAGE_MOUNT_BRONZE = f"{self.STORAGE_MOUNT_PATH}{self.config.get('storage.container.name.bronze')}"
        self.STORAGE_BRONZE_REDE_REFERENCIADA = f"{self.STORAGE_MOUNT_BRONZE}{self.config.get('storage.path.canais.redereferenciada')}"
        self.STORAGE_BRONZE_REDE_REFERENCIADA_COBERTURAS = f"{self.STORAGE_MOUNT_BRONZE}{self.config.get('storage.path.canais.redereferenciada.coberturas')}"

        # STORAGE SILVER
        self.STORAGE_MOUNT_SILVER = f"{self.STORAGE_MOUNT_PATH}{self.config.get('storage.container.name.silver')}"
        self.STORAGE_SILVER_REDE_REFERENCIADA = f"{self.STORAGE_MOUNT_SILVER}{self.config.get('storage.path.canais.redereferenciada')}"
        self.STORAGE_SILVER_REDE_REFERENCIADA_INVALIDOS = f"{self.STORAGE_MOUNT_SILVER}{self.config.get('storage.path.canais.redereferenciada.invalidos')}"
        self.STORAGE_SILVER_REDE_REFERENCIADA_DELETADOS = f"{self.STORAGE_MOUNT_SILVER}{self.config.get('storage.path.canais.redereferenciada.deletados')}"

        # STORAGE GOLD
        self.STORAGE_MOUNT_GOLD = f"{self.STORAGE_MOUNT_PATH}{self.config.get('storage.container.name.gold')}"
        self.STORAGE_GOLD_REDE_REFERENCIADA = f"{self.STORAGE_MOUNT_GOLD}{self.config.get('storage.path.canais.redereferenciada')}"

from opin_lib_canais_rede_referenciada_dados.config.configuration import Configuration
from opin_lib_canais_rede_referenciada_dados.config.util.dbutils.dbutils import DBUtils
from opin_lib_canais_rede_referenciada_dados.config.util.environment import Environment


class DBUtilsDatabricks(DBUtils):

    def __init__(self, env: Environment, config: Configuration, dbutils):
        self._env = env
        self._dbutils = dbutils
        self._config = config
        self._secret_scope_name = self._get_secret_scope_name(env)
        self._secret_scope_name_cosmos = self._get_secret_scope_name_cosmos(env)

    def fs_ls(self, path):
        return self._dbutils.fs.ls(path)

    def fs_rm(self, path, recursive: bool):
        return self._dbutils.fs.rm(path, recursive)

    def get_kvault(self, key: str) -> str:
        scope = f"{self._secret_scope_name}"
        scope_cosmos = f"{self._secret_scope_name_cosmos}"
        key = self._config.get(key)
        if (key =='azpcscosmoscanais'):
            return self._dbutils.secrets.get(scope=scope_cosmos, key=key)
        return self._dbutils.secrets.get(scope=scope, key=key)

    def get_url_sql(self, env: Environment):
        env_current = env.env_current.value.lower()
        return f"azu-bssqlsrvcanais-{env_current}-opin-002.database.windows.net"

    def get_database_sql(self, env: Environment):
        env_current = env.env_current.value.lower()
        return f"PWAPCANAIS{env_current}002"

    @staticmethod
    def _get_secret_scope_name(env: Environment):
        env_current = env.env_current.value.lower()
        prefix_secret_scope_name = f"azu-bsengdadossecretscope-{env_current}"
        return f"{prefix_secret_scope_name}-opin-001"

    @staticmethod
    def _get_secret_scope_name_cosmos(env: Environment):
        env_current = env.env_current.value.lower()
        prefix_secret_scope_name_cosmos = f"azu-bscosmossecretscope-{env_current}"
        return f"{prefix_secret_scope_name_cosmos}-opin-001"

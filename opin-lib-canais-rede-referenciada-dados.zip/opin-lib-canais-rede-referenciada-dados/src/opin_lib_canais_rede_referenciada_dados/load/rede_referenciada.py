from pyspark.sql import DataFrame
import pyspark.sql.types as t
import pyspark.sql.functions as f
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_db_fields import EnumDbFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_week_day_index import EnumWeekDayIndex


def get_identification_as_json(dataframe: DataFrame):
    dataframe = dataframe.select(EnumSilverFields.ROW_ID.value,
                                 EnumSilverFields.MARCA.value,
                                 EnumSilverFields.NOME_SOCIEDADE.value,
                                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value
                                 ).distinct()

    identification_as_json = dataframe \
        .withColumn(EnumDbFields.IDENTIFICACAO.value,
                    f.concat(
                        f.lit('{"'),
                        f.lit(f'{EnumDbFields.NOME_REDE_REFERENCIADA.value}": "'),
                        f.col(EnumSilverFields.NOME_REDE_REFERENCIADA.value),
                        f.lit(f'", "{EnumDbFields.CNPJ_REDE_REFERENCIADA.value}": "'),
                        f.col(EnumSilverFields.CNPJ_REDE_REFERENCIADA.value),
                        f.lit('"}')
                    ))

    return identification_as_json


def get_identification_schema():
    schema = t.StructType([
        t.StructField(EnumDbFields.NOME_REDE_REFERENCIADA.value, t.StringType(), True),
        t.StructField(EnumDbFields.CNPJ_REDE_REFERENCIADA.value, t.StringType(), True)
    ])

    return schema


def get_identification(data: DataFrame):
    schema = get_identification_schema()
    return data.withColumn(EnumDbFields.IDENTIFICACAO.value,
                           f.from_json(f.col(EnumDbFields.IDENTIFICACAO.value), schema))


def get_postal_address_as_json(dataframe: DataFrame):
    dataframe = dataframe.select(EnumSilverFields.MARCA.value,
                                 EnumSilverFields.NOME_SOCIEDADE.value,
                                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                                 EnumSilverFields.ENDERECO.value,
                                 EnumSilverFields.COMPLEMENTO.value,
                                 EnumSilverFields.BAIRRO.value,
                                 EnumSilverFields.MUNICIPIO.value,
                                 EnumSilverFields.UF.value,
                                 EnumSilverFields.CEP.value,
                                 EnumSilverFields.PAIS.value,
                                 EnumSilverFields.COD_PAIS.value,
                                 EnumSilverFields.LATITUDE.value,
                                 EnumSilverFields.LONGITUDE.value,
                                 EnumSilverFields.COD_IBGE.value
                                 ).distinct()

    postal_address_as_json = dataframe \
        .withColumn(EnumDbFields.ENDERECO_POSTAL.value,
                    f.concat_ws("",
                                f.lit('{"'),
                                f.lit(f'{EnumDbFields.ENDERECO.value}": "'),
                                f.col(EnumSilverFields.ENDERECO.value),
                                f.lit(f'", "{EnumDbFields.COMPLEMENTO.value}": "'),
                                f.col(EnumSilverFields.COMPLEMENTO.value),
                                f.lit(f'", "{EnumDbFields.BAIRRO.value}": "'),
                                f.col(EnumSilverFields.BAIRRO.value),
                                f.lit(f'", "{EnumDbFields.MUNICIPIO.value}": "'),
                                f.col(EnumSilverFields.MUNICIPIO.value),
                                f.lit(f'", "{EnumDbFields.COD_IBGE.value}": "'),
                                f.col(EnumSilverFields.COD_IBGE.value),
                                f.lit(f'", "{EnumDbFields.UF.value}": "'),
                                f.col(EnumSilverFields.UF.value),
                                f.lit(f'", "{EnumDbFields.CEP.value}": "'),
                                f.col(EnumSilverFields.CEP.value),
                                f.lit(f'", "{EnumDbFields.PAIS.value}": "'),
                                f.col(EnumSilverFields.PAIS.value),
                                f.lit(f'", "{EnumDbFields.COD_PAIS.value}": "'),
                                f.col(EnumSilverFields.COD_PAIS.value),
                                f.when((f.col(EnumSilverFields.LATITUDE.value).isNotNull() & f.col(
                                    EnumSilverFields.LONGITUDE.value).isNotNull()),
                                       f.concat(
                                           f.lit(f'", "{EnumDbFields.COORDENADAS.value}": '),
                                           f.lit('{"'),
                                           f.lit(f'{EnumDbFields.LATITUDE.value}": "'),
                                           f.col(EnumSilverFields.LATITUDE.value),
                                           f.lit(f'", "{EnumDbFields.LONGITUDE.value}": "'),
                                           f.col(EnumSilverFields.LONGITUDE.value),
                                           f.lit('"}'),
                                           f.lit('}')))
                                .otherwise(f.concat_ws("",
                                                       f.lit(f'", "{EnumDbFields.COORDENADAS.value}":'),
                                                       f.lit("null"), f.lit('}')))
                                ))

    return postal_address_as_json


def get_postal_address_schema():
    schema = t.StructType([
        t.StructField(EnumDbFields.ENDERECO.value, t.StringType(), True),
        t.StructField(EnumDbFields.COMPLEMENTO.value, t.StringType(), True),
        t.StructField(EnumDbFields.BAIRRO.value, t.StringType(), True),
        t.StructField(EnumDbFields.MUNICIPIO.value, t.StringType(), True),
        t.StructField(EnumDbFields.COD_IBGE.value, t.StringType(), True),
        t.StructField(EnumDbFields.UF.value, t.StringType(), True),
        t.StructField(EnumDbFields.CEP.value, t.StringType(), True),
        t.StructField(EnumDbFields.PAIS.value, t.StringType(), True),
        t.StructField(EnumDbFields.COD_PAIS.value, t.StringType(), True),
        t.StructField(EnumDbFields.COORDENADAS.value,
                      t.StructType([
                          t.StructField(EnumDbFields.LATITUDE.value, t.StringType(), True),
                          t.StructField(EnumDbFields.LONGITUDE.value, t.StringType(), True)]), True)
    ])

    return schema


def get_postal_address(data: DataFrame):
    schema = get_postal_address_schema()
    return data.withColumn(EnumDbFields.ENDERECO_POSTAL.value,
                           f.from_json(f.col(EnumDbFields.ENDERECO_POSTAL.value), schema))


def get_postal_address_list(dataframe: DataFrame):
    postal_address_as_json = dataframe.groupby(EnumSilverFields.MARCA.value,
                                               EnumSilverFields.NOME_SOCIEDADE.value,
                                               EnumSilverFields.CNPJ_SOCIEDADE.value,
                                               EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                               EnumSilverFields.CNPJ_REDE_REFERENCIADA.value) \
        .agg(f.collect_list(f.col(EnumDbFields.ENDERECO_POSTAL.value))
             .alias(EnumDbFields.ENDERECO_POSTAL.value))

    return postal_address_as_json


def get_products_as_json(dataframe: DataFrame):
    group_by = dataframe.groupby(EnumSilverFields.MARCA.value,
                                 EnumSilverFields.NOME_SOCIEDADE.value,
                                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                                 EnumSilverFields.NOME_PRODUTO.value,
                                 EnumSilverFields.CODIGO_PRODUTO.value)

    products_as_json = group_by \
        .agg(
        f.concat_ws("",
                    f.lit('{"'),
                    f.lit(f'{EnumDbFields.NOME_PRODUTO.value}": "'),
                    f.col(EnumSilverFields.NOME_PRODUTO.value),
                    f.lit(f'", "{EnumDbFields.CODIGO_PRODUTO.value}": "'),
                    f.col(EnumSilverFields.CODIGO_PRODUTO.value),
                    f.lit(f'", "{EnumDbFields.NOME_COBERTURA.value}":'),
                    f.to_json(f.collect_set(f.col(EnumSilverFields.NOME_COBERTURA.value))),
                    f.lit('}')
                    ).alias(EnumDbFields.PRODUTOS.value))

    return products_as_json


def get_products_schema():
    schema = t.StructType([
        t.StructField(EnumDbFields.NOME_PRODUTO.value, t.StringType(), True),
        t.StructField(EnumDbFields.CODIGO_PRODUTO.value, t.StringType(), True),
        t.StructField(EnumDbFields.NOME_COBERTURA.value, t.ArrayType(t.StringType(), True))
    ])

    return schema


def get_products(data: DataFrame):
    schema = get_products_schema()
    return data.withColumn(EnumDbFields.PRODUTOS.value,
                           f.from_json(f.col(EnumDbFields.PRODUTOS.value), schema))


def get_products_list(dataframe: DataFrame):
    products_as_json = dataframe.groupby(EnumSilverFields.MARCA.value,
                                         EnumSilverFields.NOME_SOCIEDADE.value,
                                         EnumSilverFields.CNPJ_SOCIEDADE.value,
                                         EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                         EnumSilverFields.CNPJ_REDE_REFERENCIADA.value) \
        .agg(f.collect_list(f.col(EnumDbFields.PRODUTOS.value))
             .alias(EnumDbFields.PRODUTOS.value))

    return products_as_json


def get_access_fields(dataframe: DataFrame):
    dataframe = dataframe.select(EnumSilverFields.MARCA.value,
                                 EnumSilverFields.NOME_SOCIEDADE.value,
                                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                                 EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                                 EnumSilverFields.TIPO_TELEFONE.value,
                                 EnumSilverFields.DDI.value,
                                 EnumSilverFields.DDD.value,
                                 EnumSilverFields.NUM_TELEFONE.value,
                                 EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                                 EnumSilverFields.HORARIO_ENCERRAMENTO.value,
                                 EnumSilverFields.HORARIO_ABERTURA.value).distinct()

    return dataframe


def get_access_phones_as_list(dataframe: DataFrame):
    dataframe = dataframe.select(EnumSilverFields.MARCA.value,
                                 EnumSilverFields.NOME_SOCIEDADE.value,
                                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                                 EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                                 EnumSilverFields.TIPO_TELEFONE.value,
                                 EnumSilverFields.DDI.value,
                                 EnumSilverFields.DDD.value,
                                 EnumSilverFields.NUM_TELEFONE.value,
                                 ).distinct()

    phones_as_list = dataframe \
        .groupby(EnumSilverFields.MARCA.value,
                 EnumSilverFields.NOME_SOCIEDADE.value,
                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                 EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value) \
        .agg(
        f.concat(
            f.to_json(
                f.collect_list(f.create_map(
                    f.lit(EnumDbFields.TIPO_TELEFONE.value), f.col(EnumSilverFields.TIPO_TELEFONE.value),
                    f.lit(EnumDbFields.DDI.value), f.col(EnumSilverFields.DDI.value),
                    f.lit(EnumDbFields.DDD.value), f.col(EnumSilverFields.DDD.value),
                    f.lit(EnumDbFields.NUM_TELEFONE.value), f.col(EnumSilverFields.NUM_TELEFONE.value),
                ))
            )
        ).alias(EnumDbFields.TELEFONES.value)
    )

    return phones_as_list


def get_access_standards_as_list(dataframe: DataFrame):
    dataframe = dataframe.select(EnumSilverFields.MARCA.value,
                                 EnumSilverFields.NOME_SOCIEDADE.value,
                                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                                 EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
                                 EnumSilverFields.DIAS_FUNCIONAMENTO.value,
                                 EnumSilverFields.HORARIO_ENCERRAMENTO.value,
                                 EnumSilverFields.HORARIO_ABERTURA.value).distinct()

    standard_with_index = dataframe.withColumn(EnumDbFields.INDICE.value,
                                               f.when(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value) ==
                                                      EnumWeekDayIndex.DOMINGO.name,
                                                      EnumWeekDayIndex.DOMINGO.value)
                                               .when(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value) ==
                                                     EnumWeekDayIndex.SEGUNDA_FEIRA.name,
                                                     EnumWeekDayIndex.SEGUNDA_FEIRA.value)
                                               .when(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value) ==
                                                     EnumWeekDayIndex.TERCA_FEIRA.name,
                                                     EnumWeekDayIndex.TERCA_FEIRA.value)
                                               .when(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value) ==
                                                     EnumWeekDayIndex.QUARTA_FEIRA.name,
                                                     EnumWeekDayIndex.QUARTA_FEIRA.value)
                                               .when(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value) ==
                                                     EnumWeekDayIndex.QUINTA_FEIRA.name,
                                                     EnumWeekDayIndex.QUINTA_FEIRA.value)
                                               .when(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value) ==
                                                     EnumWeekDayIndex.SEXTA_FEIRA.name,
                                                     EnumWeekDayIndex.SEXTA_FEIRA.value)
                                               .when(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value) ==
                                                     EnumWeekDayIndex.SABADO.name,
                                                     EnumWeekDayIndex.SABADO.value)
                                               .otherwise(f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value))
                                               ).distinct()
    standard_sort = standard_with_index.orderBy(EnumDbFields.INDICE.value, ascending=True)
    standards_as_list = standard_sort \
        .groupby(EnumSilverFields.MARCA.value,
                 EnumSilverFields.NOME_SOCIEDADE.value,
                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                 EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value) \
        .agg(
        f.concat(
            f.to_json(
                f.collect_list(f.create_map(
                    f.lit(EnumDbFields.HORARIO_ABERTURA.value), f.col(EnumSilverFields.HORARIO_ABERTURA.value),
                    f.lit(EnumDbFields.HORARIO_ENCERRAMENTO.value), f.col(EnumSilverFields.HORARIO_ENCERRAMENTO.value),
                    f.lit(EnumDbFields.DIAS_FUNCIONAMENTO.value), f.col(EnumSilverFields.DIAS_FUNCIONAMENTO.value),
                ))
            )
        ).alias(EnumDbFields.FUNCIONAMENTO.value)
    )

    standards_as_list = standards_as_list.withColumn(EnumDbFields.FUNCIONAMENTO.value, f.when(
        (f.col(EnumDbFields.FUNCIONAMENTO.value).contains('"openingTime":"","closingTime":"","weekday":""')), "[]"
    )
    .otherwise(f.col(EnumDbFields.FUNCIONAMENTO.value))
    )

    return standards_as_list


def get_access_as_json(standard: DataFrame, phones: DataFrame):
    key = [EnumSilverFields.MARCA.value,
           EnumSilverFields.NOME_SOCIEDADE.value,
           EnumSilverFields.CNPJ_SOCIEDADE.value,
           EnumSilverFields.NOME_REDE_REFERENCIADA.value,
           EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
           EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value]

    access_as_json = phones.join(standard, key, 'inner')

    access_as_json = access_as_json.withColumn(EnumDbFields.FORMA_ACESSO.value,
                                               f.concat(
                                                   f.lit('{'),
                                                   f.lit(f'"{EnumDbFields.FUNCIONAMENTO.value}":'),
                                                   f.col(EnumDbFields.FUNCIONAMENTO.value),
                                                   f.lit(f',"{EnumDbFields.INDICADOR_RESTRICAO_ACESSO.value}":'),
                                                   f.col(EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value),
                                                   f.lit(f',"{EnumDbFields.TELEFONES.value}":'),
                                                   f.col(EnumDbFields.TELEFONES.value),
                                                   f.lit('}')
                                               )).distinct()

    access_as_json = (access_as_json
                      .drop(EnumDbFields.TELEFONES.value)
                      .drop(EnumDbFields.FUNCIONAMENTO.value))

    return access_as_json


def get_access_schema():
    schema = t.StructType([
        t.StructField(EnumDbFields.FUNCIONAMENTO.value,
                      t.ArrayType(
                          t.StructType([
                              t.StructField(EnumDbFields.HORARIO_ABERTURA.value, t.StringType(), True),
                              t.StructField(EnumDbFields.HORARIO_ENCERRAMENTO.value, t.StringType(), True),
                              t.StructField(EnumDbFields.DIAS_FUNCIONAMENTO.value, t.StringType(), True),
                          ]), True)),
        t.StructField(EnumDbFields.INDICADOR_RESTRICAO_ACESSO.value, t.BooleanType(), False),
        t.StructField(EnumDbFields.TELEFONES.value,
                      t.ArrayType(
                          t.StructType([
                              t.StructField(EnumDbFields.TIPO_TELEFONE.value, t.StringType(), True),
                              t.StructField(EnumDbFields.DDI.value, t.StringType(), True),
                              t.StructField(EnumDbFields.DDD.value, t.StringType(), True),
                              t.StructField(EnumDbFields.NUM_TELEFONE.value, t.StringType(), True)
                          ]), True))
    ])

    return schema


def get_access(dataframe: DataFrame):
    schema = get_access_schema()
    return dataframe.withColumn(EnumDbFields.FORMA_ACESSO.value,
                                f.from_json(f.col(EnumDbFields.FORMA_ACESSO.value), schema))


def get_access_list(dataframe: DataFrame):
    access_as_json = dataframe.groupby(EnumSilverFields.MARCA.value,
                                       EnumSilverFields.NOME_SOCIEDADE.value,
                                       EnumSilverFields.CNPJ_SOCIEDADE.value,
                                       EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                       EnumSilverFields.CNPJ_REDE_REFERENCIADA.value) \
        .agg(f.collect_list(f.col(EnumDbFields.FORMA_ACESSO.value))
             .alias(EnumDbFields.FORMA_ACESSO.value))

    return access_as_json


def get_services_fields(dataframe: DataFrame):
    dataframe = dataframe.select(EnumSilverFields.MARCA.value,
                                 EnumSilverFields.NOME_SOCIEDADE.value,
                                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                                 EnumSilverFields.TIPO_SERVICO.value,
                                 EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                                 EnumSilverFields.NOME_SERVICOS_PRESTADOS.value,
                                 EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value).distinct()

    return dataframe


def get_services_as_json(dataframe: DataFrame):
    services_as_json = dataframe \
        .groupby(EnumSilverFields.MARCA.value,
                 EnumSilverFields.NOME_SOCIEDADE.value,
                 EnumSilverFields.CNPJ_SOCIEDADE.value,
                 EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                 EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
                 EnumSilverFields.TIPO_SERVICO.value,
                 EnumSilverFields.TIPO_SERVICO_OUTROS.value,
                 EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value) \
        .agg(
        f.concat(
            f.lit('{'),
            f.lit(f'"{EnumDbFields.TIPO_SERVICO.value}":"'),
            f.col(EnumSilverFields.TIPO_SERVICO.value),
            f.lit(f'","{EnumDbFields.TIPO_SERVICO_OUTROS.value}":"'),
            f.col(EnumSilverFields.TIPO_SERVICO_OUTROS.value),
            f.lit(f'","{EnumDbFields.NOME_SERVICOS_PRESTADOS.value}":'),
            f.to_json(f.collect_list(f.col(EnumSilverFields.NOME_SERVICOS_PRESTADOS.value))),
            f.lit(f',"{EnumDbFields.DESCRICAO_TIPO_SERVICOS.value}":"'),
            f.col(EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value),
            f.lit('"}')
        ).alias(EnumDbFields.SERVICOS.value)
    )

    return services_as_json


def get_services_schema():
    schema = t.StructType([
        t.StructField(EnumDbFields.TIPO_SERVICO.value, t.StringType(), False),
        t.StructField(EnumDbFields.TIPO_SERVICO_OUTROS.value, t.StringType(), True),
        t.StructField(EnumDbFields.NOME_SERVICOS_PRESTADOS.value, t.ArrayType(t.StringType(), True)),
        t.StructField(EnumDbFields.DESCRICAO_TIPO_SERVICOS.value, t.StringType(), True),

    ])

    return schema


def get_services(dataframe: DataFrame):
    schema = get_services_schema()
    return dataframe.withColumn(EnumDbFields.SERVICOS.value,
                                f.from_json(f.col(EnumDbFields.SERVICOS.value), schema))


def get_services_list(dataframe: DataFrame):
    services_as_json = dataframe.groupby(EnumSilverFields.MARCA.value,
                                         EnumSilverFields.NOME_SOCIEDADE.value,
                                         EnumSilverFields.CNPJ_SOCIEDADE.value,
                                         EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                                         EnumSilverFields.CNPJ_REDE_REFERENCIADA.value) \
        .agg(f.collect_list(f.col(EnumDbFields.SERVICOS.value))
             .alias(EnumDbFields.SERVICOS.value))

    return services_as_json


def join_json_items(identification: DataFrame, products: DataFrame, postal_addresses: DataFrame,
                    access: DataFrame, services: DataFrame):
    ids = [EnumSilverFields.MARCA.value,
           EnumSilverFields.NOME_SOCIEDADE.value,
           EnumSilverFields.CNPJ_SOCIEDADE.value,
           EnumSilverFields.NOME_REDE_REFERENCIADA.value,
           EnumSilverFields.CNPJ_REDE_REFERENCIADA.value]

    data = (identification.join(products, ids, 'inner')
            .join(postal_addresses, ids, 'inner')
            .join(access, ids, 'inner')
            .join(services, ids, 'inner'))

    data = data.select(identification[EnumSilverFields.MARCA.value],
                       identification[EnumSilverFields.NOME_SOCIEDADE.value],
                       identification[EnumSilverFields.CNPJ_SOCIEDADE.value],
                       EnumDbFields.IDENTIFICACAO.value,
                       EnumDbFields.PRODUTOS.value,
                       EnumDbFields.ENDERECO_POSTAL.value,
                       EnumDbFields.FORMA_ACESSO.value,
                       EnumDbFields.SERVICOS.value,
                       EnumSilverFields.ROW_ID.value)

    data = data \
        .withColumnRenamed(EnumSilverFields.MARCA.value, EnumDbFields.MARCA.value) \
        .withColumnRenamed(EnumSilverFields.NOME_SOCIEDADE.value, EnumDbFields.NOME_SOCIEDADE.value) \
        .withColumnRenamed(EnumSilverFields.CNPJ_SOCIEDADE.value, EnumDbFields.CNPJ_SOCIEDADE.value) \
        .withColumnRenamed(EnumSilverFields.ROW_ID.value, EnumDbFields.ROW_ID.value)

    return data

import pyspark.sql.functions as f

from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_domain import EnumPhoneType, EnumServiceType, \
    EnumServiceName, EnumWeekDay, EnumCountrySubDivisionType, EnumCountryType
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_fields_length import EnumFieldsLength
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import \
    EnumBronzeFields as Enum


class RedeReferenciadaConditions:
    @staticmethod
    def mandatory_fields():
        return f.array(
            f.when(((f.col(Enum.MARCA.value).isNull()) | (f.col(Enum.MARCA.value) == "")), f.lit(Enum.MARCA.value)),
            f.when(((f.col(Enum.NOME_SOCIEDADE.value).isNull()) | (f.col(Enum.NOME_SOCIEDADE.value) == "")),
                   f.lit(Enum.NOME_SOCIEDADE.value)),
            f.when(((f.col(Enum.CNPJ_SOCIEDADE.value).isNull()) | (f.col(Enum.CNPJ_SOCIEDADE.value) == "")),
                   f.lit(Enum.CNPJ_SOCIEDADE.value)),
            f.when(((f.col(Enum.NOME_REDE_REFERENCIADA.value).isNull()) | (
                    f.col(Enum.NOME_REDE_REFERENCIADA.value) == "")),
                   f.lit(Enum.NOME_REDE_REFERENCIADA.value)),
            f.when(((f.col(Enum.CNPJ_REDE_REFERENCIADA.value).isNull()) | (
                    f.col(Enum.CNPJ_REDE_REFERENCIADA.value) == "")),
                   f.lit(Enum.CNPJ_REDE_REFERENCIADA.value)),
            f.when(((f.col(Enum.NOME_PRODUTO.value).isNull()) | (f.col(Enum.NOME_PRODUTO.value) == "")),
                   f.lit(Enum.NOME_PRODUTO.value)),
            f.when(((f.col(Enum.CODIGO_PRODUTO.value).isNull()) | (f.col(Enum.CODIGO_PRODUTO.value) == "")),
                   f.lit(Enum.CODIGO_PRODUTO.value)),
            f.when(((f.col(Enum.ENDERECO.value).isNull()) | (f.col(Enum.ENDERECO.value) == "")),
                   f.lit(Enum.ENDERECO.value)),
            f.when(((f.col(Enum.MUNICIPIO.value).isNull()) | (f.col(Enum.MUNICIPIO.value) == "")),
                   f.lit(Enum.MUNICIPIO.value)),
            f.when(((f.col(Enum.UF.value).isNull()) | (f.col(Enum.UF.value) == "")), f.lit(Enum.UF.value)),
            f.when(((f.col(Enum.COD_IBGE.value).isNull()) | (f.col(Enum.COD_IBGE.value) == "")),
                   f.lit(Enum.COD_IBGE.value)),
            f.when(((f.col(Enum.CEP.value).isNull()) | (f.col(Enum.CEP.value) == "")), f.lit(Enum.CEP.value)),
            f.when(((f.col(Enum.TIPO_SERVICO.value).isNull()) | (f.col(Enum.TIPO_SERVICO.value) == "")),
                   f.lit(Enum.TIPO_SERVICO.value)),
            f.when(((f.col(Enum.NOME_SERVICOS_PRESTADOS.value).isNull()) | (
                    f.col(Enum.NOME_SERVICOS_PRESTADOS.value) == "")),
                   f.lit(Enum.NOME_SERVICOS_PRESTADOS.value)),
            f.when(((f.col(Enum.DESCRICAO_TIPO_SERVICOS.value).isNull()) | (
                    f.col(Enum.DESCRICAO_TIPO_SERVICOS.value) == "")),
                   f.lit(Enum.DESCRICAO_TIPO_SERVICOS.value)),
        )

    @staticmethod
    def length_fields():
        return f.array(
            f.when(f.length(f.col(Enum.MARCA.value)) >
                   EnumFieldsLength.MARCA.value,
                   f.lit(Enum.MARCA.value)),
            f.when(f.length(f.col(Enum.NOME_SOCIEDADE.value)) >
                   EnumFieldsLength.NOME_SOCIEDADE.value,
                   f.lit(Enum.NOME_SOCIEDADE.value)),
            f.when(f.length(f.col(Enum.CNPJ_SOCIEDADE.value)) >
                   EnumFieldsLength.CNPJ_SOCIEDADE.value,
                   f.lit(Enum.CNPJ_SOCIEDADE.value)),
            f.when(f.length(f.col(Enum.NOME_REDE_REFERENCIADA.value)) >
                   EnumFieldsLength.NOME_REDE_REFERENCIADA.value, f.lit(Enum.NOME_REDE_REFERENCIADA.value)),
            f.when(f.length(f.col(Enum.CNPJ_REDE_REFERENCIADA.value)) >
                   EnumFieldsLength.CNPJ_REDE_REFERENCIADA.value, f.lit(Enum.CNPJ_REDE_REFERENCIADA.value)),
            f.when(f.length(f.col(Enum.NOME_PRODUTO.value)) >
                   EnumFieldsLength.NOME_PRODUTO.value, f.lit(Enum.NOME_PRODUTO.value)),
            f.when(f.length(f.col(Enum.CODIGO_PRODUTO.value)) >
                   EnumFieldsLength.CODIGO_PRODUTO.value, f.lit(Enum.CODIGO_PRODUTO.value)),
            f.when(f.length(f.col(Enum.NOME_COBERTURA.value)) >
                   EnumFieldsLength.NOME_COBERTURA.value, f.lit(Enum.NOME_COBERTURA.value)),
            f.when(f.length(f.col(Enum.ENDERECO.value)) >
                   EnumFieldsLength.ENDERECO.value, f.lit(Enum.ENDERECO.value)),
            f.when(f.length(f.col(Enum.COMPLEMENTO.value)) >
                   EnumFieldsLength.COMPLEMENTO.value, f.lit(Enum.COMPLEMENTO.value)),
            f.when(f.length(f.col(Enum.BAIRRO.value)) >
                   EnumFieldsLength.BAIRRO.value, f.lit(Enum.BAIRRO.value)),
            f.when(f.length(f.col(Enum.MUNICIPIO.value)) >
                   EnumFieldsLength.MUNICIPIO.value, f.lit(Enum.MUNICIPIO.value)),
            f.when(f.length(f.col(Enum.CEP.value)) >
                   EnumFieldsLength.CEP.value, f.lit(Enum.CEP.value)),
            f.when(f.length(f.col(Enum.COD_PAIS.value)) >
                   EnumFieldsLength.COD_PAIS.value, f.lit(Enum.COD_PAIS.value)),
            f.when(f.length(f.col(Enum.LATITUDE.value)) >
                   EnumFieldsLength.LATITUDE.value, f.lit(Enum.LATITUDE.value)),
            f.when(f.length(f.col(Enum.LONGITUDE.value)) >
                   EnumFieldsLength.LONGITUDE.value, f.lit(Enum.LONGITUDE.value)),
            f.when(f.length(f.col(Enum.DDI.value)) >
                   EnumFieldsLength.DDI.value, f.lit(Enum.DDI.value)),
            f.when(f.length(f.col(Enum.DDD.value)) >
                   EnumFieldsLength.DDD.value, f.lit(Enum.DDD.value)),
            f.when(f.length(f.col(Enum.NUM_TELEFONE.value)) >
                   EnumFieldsLength.NUM_TELEFONE.value, f.lit(Enum.NUM_TELEFONE.value)),
            f.when(f.length(f.col(Enum.TIPO_SERVICO_OUTROS.value)) >
                   EnumFieldsLength.TIPO_SERVICO_OUTROS.value, f.lit(Enum.TIPO_SERVICO_OUTROS.value)),
            f.when(f.length(f.col(Enum.COD_IBGE.value)) >
                   EnumFieldsLength.COD_IBGE.value, f.lit(Enum.COD_IBGE.value)),
            f.when(f.length(f.col(Enum.HORARIO_ABERTURA.value)) >
                   EnumFieldsLength.HORARIO_ABERTURA.value, f.lit(Enum.HORARIO_ABERTURA.value)),
            f.when(f.length(f.col(Enum.HORARIO_ENCERRAMENTO.value)) >
                   EnumFieldsLength.HORARIO_ENCERRAMENTO.value, f.lit(Enum.HORARIO_ENCERRAMENTO.value)),
            f.when(f.length(f.col(Enum.DESCRICAO_TIPO_SERVICOS.value)) >
                   EnumFieldsLength.DESCRICAO_TIPO_SERVICOS.value, f.lit(Enum.DESCRICAO_TIPO_SERVICOS.value))
        )

    @staticmethod
    def rename_fields():
        return {
            Enum.MARCA.value: EnumSilverFields.MARCA.value,
            Enum.NOME_SOCIEDADE.value: EnumSilverFields.NOME_SOCIEDADE.value,
            Enum.CNPJ_SOCIEDADE.value: EnumSilverFields.CNPJ_SOCIEDADE.value,
            Enum.NOME_REDE_REFERENCIADA.value: EnumSilverFields.NOME_REDE_REFERENCIADA.value,
            Enum.CNPJ_REDE_REFERENCIADA.value: EnumSilverFields.CNPJ_REDE_REFERENCIADA.value,
            Enum.NOME_PRODUTO.value: EnumSilverFields.NOME_PRODUTO.value,
            Enum.CODIGO_PRODUTO.value: EnumSilverFields.CODIGO_PRODUTO.value,
            Enum.NOME_COBERTURA.value: EnumSilverFields.NOME_COBERTURA.value,
            Enum.ENDERECO.value: EnumSilverFields.ENDERECO.value,
            Enum.COMPLEMENTO.value: EnumSilverFields.COMPLEMENTO.value,
            Enum.BAIRRO.value: EnumSilverFields.BAIRRO.value,
            Enum.MUNICIPIO.value: EnumSilverFields.MUNICIPIO.value,
            Enum.UF.value: EnumSilverFields.UF.value,
            Enum.COD_IBGE.value: EnumSilverFields.COD_IBGE.value,
            Enum.CEP.value: EnumSilverFields.CEP.value,
            Enum.PAIS.value: EnumSilverFields.PAIS.value,
            Enum.COD_PAIS.value: EnumSilverFields.COD_PAIS.value,
            Enum.LATITUDE.value: EnumSilverFields.LATITUDE.value,
            Enum.LONGITUDE.value: EnumSilverFields.LONGITUDE.value,
            Enum.HORARIO_ABERTURA.value: EnumSilverFields.HORARIO_ABERTURA.value,
            Enum.HORARIO_ENCERRAMENTO.value: EnumSilverFields.HORARIO_ENCERRAMENTO.value,
            Enum.DIAS_FUNCIONAMENTO.value: EnumSilverFields.DIAS_FUNCIONAMENTO.value,
            Enum.INDICADOR_RESTRICAO_ACESSO.value: EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value,
            Enum.TIPO_TELEFONE.value: EnumSilverFields.TIPO_TELEFONE.value,
            Enum.DDI.value: EnumSilverFields.DDI.value,
            Enum.DDD.value: EnumSilverFields.DDD.value,
            Enum.NUM_TELEFONE.value: EnumSilverFields.NUM_TELEFONE.value,
            Enum.TIPO_SERVICO.value: EnumSilverFields.TIPO_SERVICO.value,
            Enum.TIPO_SERVICO_OUTROS.value: EnumSilverFields.TIPO_SERVICO_OUTROS.value,
            Enum.NOME_SERVICOS_PRESTADOS.value: EnumSilverFields.NOME_SERVICOS_PRESTADOS.value,
            Enum.DESCRICAO_TIPO_SERVICOS.value: EnumSilverFields.DESCRICAO_TIPO_SERVICOS.value
        }

    @staticmethod
    def options_fields():
        name_services_list = [name.value for name in EnumServiceName]
        service_type_list = [service_type.value for service_type in EnumServiceType]
        week_day_list = [week_day.value for week_day in EnumWeekDay]
        uf_list = [uf.value for uf in EnumCountrySubDivisionType]
        country_list = [country.value for country in EnumCountryType]

        return f.array(
            f.when(~f.col(Enum.TIPO_SERVICO.value).isin(service_type_list), f.lit(Enum.TIPO_SERVICO.value)),
            f.when(~f.col(Enum.DIAS_FUNCIONAMENTO.value).isin(week_day_list), f.lit(Enum.DIAS_FUNCIONAMENTO.value)),
            f.when(~f.col(Enum.UF.value).isin(uf_list), f.lit(Enum.UF.value)),
            f.when(~f.col(Enum.PAIS.value).isin(country_list), f.lit(Enum.PAIS.value)),
            f.when(~f.col(Enum.NOME_SERVICOS_PRESTADOS.value).isin(name_services_list),
                   f.lit(Enum.NOME_SERVICOS_PRESTADOS.value))
        )

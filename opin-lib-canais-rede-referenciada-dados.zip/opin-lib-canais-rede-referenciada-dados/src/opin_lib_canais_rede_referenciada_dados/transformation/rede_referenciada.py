from pyspark.sql import DataFrame
import pyspark.sql.functions as f
import pyspark.sql.types as t
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_columns_list import EnumColumnsList
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_domain import EnumPhoneType, EnumServiceType, \
    EnumServiceName, EnumWeekDay, EnumCountryType, EnumCountrySubDivisionType
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields
from opin_lib_canais_rede_referenciada_dados.transformation.rede_referenciada_conditions import \
    RedeReferenciadaConditions as Conditions
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_data_quality import EnumDataQuality
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_fields_length import EnumFieldsLength


def mandatory_field_validator(dataframe: DataFrame):
    """Verify if a mandatory field has null value."""
    dataframe_validated = (dataframe.withColumn(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value,
                                                Conditions.mandatory_fields())
                           .withColumn(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value,
                                       f.expr(
                                           f"filter({EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value}, c -> c IS NOT NULL)"))
                           .withColumn(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value,
                                       f.concat_ws(",", f.col(
                                           EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value))))

    return dataframe_validated


def field_length_validator(dataframe: DataFrame):
    """Verify if a field has unexpected length."""
    dataframe_validated = (
        dataframe.withColumn(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value, Conditions.length_fields())
        .withColumn(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value,
                    f.expr(
                        f"filter({EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value}, c -> c IS NOT NULL)"))
        .withColumn(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value,
                    f.concat_ws(",", f.col(EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value))))

    return dataframe_validated


def options_validator(dataframe: DataFrame):
    """Verify if a field has invalid option value."""
    dataframe_validated = (
        dataframe.withColumn(EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value, Conditions.options_fields())
        .withColumn(EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value,
                    f.expr(
                        f"filter({EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value}, c -> c IS NOT NULL)"))
        .withColumn(EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value,
                    f.concat_ws(",", f.col(EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value))))

    return dataframe_validated


def remove_final_delimiter_multivalues_fields(dataframe: DataFrame, columns: list, delimiter: str):
    """Verify if a multivalues field has any delimiter at end of field and remove it."""
    for column in columns:
        dataframe = (dataframe.withColumn(column, f.when(f.trim(f.col(column)).endswith(delimiter),
                                                         f.trim(f.col(column)).substr(f.lit(1),
                                                                                      f.length(
                                                                                          f.trim(f.col(column))) - 1))
                                          .otherwise(f.col(column))))

    return dataframe


def remove_numerical_masks(dataframe: DataFrame, columns: list):
    """Remove numerical masks from fields like CNPJ, CPF, Phone Number, etc."""
    values_to_replace = "[ .,/|-]"

    for column in columns:
        dataframe = (dataframe.withColumn(column, f.regexp_replace(f.col(column), values_to_replace, '')))

    return dataframe


def explode_multivalues_fields(dataframe: DataFrame, columns: list, delimiter: str):
    """Explode multivalues fields to create a row for value."""
    for column in columns:
        dataframe = (dataframe.withColumn(column, f.explode_outer(f.split(column, delimiter))))

    return dataframe


def trim_fields(dataframe: DataFrame):
    """Explode multivalues fields to create a row for value."""
    for column in dataframe.columns:
        dataframe = (dataframe.withColumn(column, f.trim(column)))

    return dataframe


def rename_bronze_to_silver_columns(dataframe: DataFrame):
    for column, new_name in Conditions.rename_fields().items():
        dataframe = dataframe.withColumnRenamed(column, new_name)

    return dataframe


def filter_invalid_data(dataframe: DataFrame):
    dataframe_invalid = (dataframe.filter(f"""{EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value} != ''
                                          OR {EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value} != '' 
                                          OR {EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value} != '' """))

    return dataframe_invalid


def filter_valid_data(dataframe: DataFrame):
    dataframe_valid = (dataframe.filter(f"""{EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value} == ''
                                        AND {EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value} == '' 
                                        AND {EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value} == '' """)
                       .drop(EnumDataQuality.DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS.value,
                             EnumDataQuality.DATA_QUALITY_TAMANHO_INVALIDO.value,
                             EnumDataQuality.DATA_QUALITY_OPCAO_INVALIDA.value))

    return dataframe_valid


def filter_deleted_records(spark, dataframe_transformed, dataframe_silver):
    if isinstance(dataframe_silver, DataFrame) and len(dataframe_silver.take(1)) > 0:
        ids = [EnumSilverFields.MARCA.value,
               EnumSilverFields.NOME_SOCIEDADE.value,
               EnumSilverFields.CNPJ_SOCIEDADE.value,
               EnumSilverFields.NOME_REDE_REFERENCIADA.value,
               EnumSilverFields.CNPJ_REDE_REFERENCIADA.value]

        dataframe_transformed = dataframe_transformed.select(ids).distinct()
        dataframe_silver = dataframe_silver.select(ids).distinct()

        deleted_dataframe = (dataframe_silver.join(dataframe_transformed, ids, how="left_anti")
                             .withColumn(
            EnumSilverFields.ROW_ID.value, f.sha2(
                f.concat(
                    EnumSilverFields.MARCA.value,
                    EnumSilverFields.NOME_SOCIEDADE.value,
                    EnumSilverFields.CNPJ_SOCIEDADE.value,
                    EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                    EnumSilverFields.CNPJ_REDE_REFERENCIADA.value
                ), 256))
                             .select(EnumSilverFields.ROW_ID.value)
                             )

        return deleted_dataframe
    else:
        schema = t.StructType([t.StructField(EnumSilverFields.ROW_ID.value, t.StringType(), True)])
        return spark.createDataFrame([], schema=schema)


def create_row_id_field(dataframe: DataFrame):
    dataframe_with_row_id = dataframe.withColumn(
        EnumSilverFields.ROW_ID.value, f.sha2(
            f.concat(
                EnumSilverFields.MARCA.value,
                EnumSilverFields.NOME_SOCIEDADE.value,
                EnumSilverFields.CNPJ_SOCIEDADE.value,
                EnumSilverFields.NOME_REDE_REFERENCIADA.value,
                EnumSilverFields.CNPJ_REDE_REFERENCIADA.value
            ), 256))

    return dataframe_with_row_id


def treat_null_boolean_fields(dataframe: DataFrame):
    dataframe = (dataframe.withColumn(EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value,
                                      f.when((f.col(EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value).isNull())
                                             | (f.col(EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value) == ""),
                                             f.lit("false").cast("boolean"))
                                      .otherwise(
                                          f.col(EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value).cast("boolean"))
                                      ))

    return dataframe


def treat_null_values(dataframe: DataFrame, columns):
    return dataframe.fillna("", subset=columns)


def remove_accents_and_special_characters_from_fields(dataframe: DataFrame) -> DataFrame:
    char_map = {
        "[áÁâÂãÃàÀ]": "A",
        "[éÉêÊẽẼèÈ]": "E",
        "[íÍîÎĩĨìÌ]": "I",
        "[óÓôÔõÕòÒ]": "O",
        "[úÚûÛũŨùÙ]": "U",
        "[çÇ]": "C",
        "/": " "
    }

    for column in EnumColumnsList.FIELDS_WITH_OPTIONS_VALUES.value:
        for regex1, regex2 in char_map.items():
            dataframe = dataframe.withColumn(column, f.trim(f.upper(f.regexp_replace(column, regex1, regex2))))

    return dataframe


def remove_accents_and_special_characters_to_referenced_name(dataframe: DataFrame) -> DataFrame:
    char_map = {
        "[áÁâÂãÃàÀ]": "A",
        "[éÉêÊẽẼèÈ]": "E",
        "[íÍîÎĩĨìÌ]": "I",
        "[óÓôÔõÕòÒ]": "O",
        "[úÚûÛũŨùÙ]": "U",
    }

    for regex1, regex2 in char_map.items():
        dataframe = dataframe.withColumn(EnumBronzeFields.NOME_REDE_REFERENCIADA.value,
                                         f.trim(f.upper(f.regexp_replace(EnumBronzeFields.NOME_REDE_REFERENCIADA.value,
                                                                         regex1, regex2))))

    return dataframe


def get_phone_type_from_enum(dataframe: DataFrame):
    map_inter_type = {}
    for phone_type in EnumPhoneType:
        map_inter_type[phone_type.value] = phone_type.name

    dataframe = dataframe.replace(to_replace=map_inter_type, subset=[EnumBronzeFields.TIPO_TELEFONE.value])

    return dataframe


def get_service_type_from_enum(dataframe: DataFrame):
    map_inter_type = {}
    for service_type in EnumServiceType:
        map_inter_type[service_type.value] = service_type.name

    dataframe = dataframe.replace(to_replace=map_inter_type, subset=[EnumBronzeFields.TIPO_SERVICO.value])

    return dataframe


def get_week_day_from_enum(dataframe: DataFrame):
    map_inter_type = {}
    for week_day in EnumWeekDay:
        if week_day.value != '':
            map_inter_type[week_day.value] = week_day.name

    dataframe = dataframe.replace(to_replace=map_inter_type, subset=[EnumBronzeFields.DIAS_FUNCIONAMENTO.value])

    return dataframe


def get_service_name_from_enum(dataframe: DataFrame):
    map_inter_type = {}
    for service_name in EnumServiceName:
        map_inter_type[service_name.value] = service_name.name

    dataframe = dataframe.replace(to_replace=map_inter_type, subset=[EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value])

    return dataframe


def get_country_name_from_enum(dataframe: DataFrame):
    map_inter_type = {}
    for country_name in EnumCountryType:
        map_inter_type[country_name.value] = country_name.name

    dataframe = dataframe.replace(to_replace=map_inter_type, subset=[EnumBronzeFields.PAIS.value])

    return dataframe


def get_country_sub_division_name_from_enum(dataframe: DataFrame):
    map_inter_type = {}
    for uf_name in EnumCountrySubDivisionType:
        map_inter_type[uf_name.value] = uf_name.name

    dataframe = dataframe.replace(to_replace=map_inter_type, subset=[EnumBronzeFields.UF.value])

    return dataframe


def translate_options_from_enum(dataframe: DataFrame):
    translated = get_service_name_from_enum(dataframe)
    translated = get_service_type_from_enum(translated)
    translated = get_week_day_from_enum(translated)
    translated = get_country_name_from_enum(translated)

    return translated


def exploded_product_code_and_name(dataframe: DataFrame):
    dataframe = (dataframe.withColumn('tmp', f.arrays_zip(f.split(EnumBronzeFields.CODIGO_PRODUTO.value, ';'),
                                                          f.split(EnumBronzeFields.NOME_PRODUTO.value, ';')))
                 .withColumn('tmp', f.explode_outer('tmp'))
                 .withColumn(EnumBronzeFields.CODIGO_PRODUTO.value, f.col('tmp.0'))
                 .withColumn(EnumBronzeFields.NOME_PRODUTO.value, f.col('tmp.1')))

    dataframe = dataframe.drop('tmp')

    return dataframe


def treat_weekday(dataframe: DataFrame):
    dataframe = dataframe.withColumn('diasFuncionamento',
                                     f.when(f.col('diasFuncionamento').isin(['SABADO', 'DOMINGO']), f.col('diasFuncionamento')) \
                                     .when((f.col('diasFuncionamento').isNull()) | (f.col('diasFuncionamento') == ""), f.col('diasFuncionamento'))\
                                     .otherwise(f.concat(f.col('diasFuncionamento'), f.lit('-FEIRA'))))

    return dataframe


def treat_coverage_length(dataframe: DataFrame):
    dataframe = dataframe.withColumn('nomeCobertura', f.substring(f.col('nomeCobertura'), 1, EnumFieldsLength.NOME_COBERTURA.value))
    return dataframe

from enum import Enum


class EnumDataQuality(Enum):
    """Data Quality Fields"""
    DATA_QUALITY_OBRIGATORIOS_NAO_PREENCHIDOS = "camposObrigatoriosNaoPreenchidos"
    DATA_QUALITY_TAMANHO_INVALIDO = "tamanhoCampoInvalido"
    DATA_QUALITY_OPCAO_INVALIDA = "campoComOpcaoInvalida"

from enum import Enum
import pyspark.sql.types as T

from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_silver_fields import EnumSilverFields


class EnumSchemas(Enum):
    BRONZE_SCHEMA = T.StructType([T.StructField(EnumBronzeFields.MARCA.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.NOME_SOCIEDADE.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.CNPJ_SOCIEDADE.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.NOME_REDE_REFERENCIADA.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.CODIGO_PRODUTO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.ENDERECO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.COMPLEMENTO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.BAIRRO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.MUNICIPIO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.UF.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.COD_IBGE.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.CEP.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.PAIS.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.COD_PAIS.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.LATITUDE.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.LONGITUDE.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.HORARIO_ABERTURA.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.HORARIO_ENCERRAMENTO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.DIAS_FUNCIONAMENTO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value, T.BooleanType(), True),
                                  T.StructField(EnumBronzeFields.TIPO_TELEFONE.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.DDI.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.DDD.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.NUM_TELEFONE.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.TIPO_SERVICO.value, T.StringType(), True),
                                  T.StructField(EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value, T.StringType(), True)
                                  ])

    SILVER_SCHEMA = T.StructType([T.StructField(EnumSilverFields.MARCA.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.NOME_SOCIEDADE.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.CNPJ_SOCIEDADE.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.NOME_REDE_REFERENCIADA.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.CNPJ_REDE_REFERENCIADA.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.CODIGO_PRODUTO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.ENDERECO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.COMPLEMENTO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.BAIRRO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.MUNICIPIO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.UF.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.COD_IBGE.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.CEP.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.PAIS.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.COD_PAIS.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.LATITUDE.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.LONGITUDE.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.HORARIO_ABERTURA.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.HORARIO_ENCERRAMENTO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.DIAS_FUNCIONAMENTO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.INDICADOR_RESTRICAO_ACESSO.value, T.BooleanType(), True),
                                  T.StructField(EnumSilverFields.TIPO_TELEFONE.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.DDI.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.DDD.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.NUM_TELEFONE.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.TIPO_SERVICO.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.NOME_SERVICOS_PRESTADOS.value, T.StringType(), True),
                                  T.StructField(EnumSilverFields.COD_SERVICOS_PRESTADOS.value, T.StringType(), True)
                                  ])

from enum import Enum
from opin_lib_canais_rede_referenciada_dados.enum.rede_referenciada.enum_bronze_fields import EnumBronzeFields


class EnumColumnsList(Enum):
    """Conditions fields list"""
    MULTIVALUES_FIELDS = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value,
                          EnumBronzeFields.TIPO_SERVICO.value,
                          EnumBronzeFields.NOME_COBERTURA.value,
                          EnumBronzeFields.HORARIO_ABERTURA.value,
                          EnumBronzeFields.HORARIO_ENCERRAMENTO.value,
                          EnumBronzeFields.DIAS_FUNCIONAMENTO.value,
                          EnumBronzeFields.NOME_PRODUTO.value,
                          EnumBronzeFields.CODIGO_PRODUTO.value]

    COLUMNS_WITH_MASK = [EnumBronzeFields.CNPJ_SOCIEDADE.value,
                         EnumBronzeFields.CNPJ_REDE_REFERENCIADA.value,
                         EnumBronzeFields.CEP.value,
                         EnumBronzeFields.NUM_TELEFONE.value]

    COLUMNS_TO_EXPLODE = [EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value,
                          EnumBronzeFields.TIPO_SERVICO.value,
                          EnumBronzeFields.NOME_COBERTURA.value,
                          EnumBronzeFields.HORARIO_ABERTURA.value,
                          EnumBronzeFields.HORARIO_ENCERRAMENTO.value,
                          EnumBronzeFields.DIAS_FUNCIONAMENTO.value]

    COLUMNS_TO_TREAT = [EnumBronzeFields.COMPLEMENTO.value,
                        EnumBronzeFields.PAIS.value,
                        EnumBronzeFields.COD_PAIS.value,
                        EnumBronzeFields.INDICADOR_RESTRICAO_ACESSO.value,
                        EnumBronzeFields.TIPO_TELEFONE.value,
                        EnumBronzeFields.DDI.value,
                        EnumBronzeFields.DDD.value,
                        EnumBronzeFields.NUM_TELEFONE.value,
                        EnumBronzeFields.TIPO_SERVICO_OUTROS.value,
                        EnumBronzeFields.HORARIO_ABERTURA.value,
                        EnumBronzeFields.HORARIO_ENCERRAMENTO.value,
                        EnumBronzeFields.DIAS_FUNCIONAMENTO.value,
                        ]

    FIELDS_WITH_OPTIONS_VALUES = [EnumBronzeFields.TIPO_SERVICO.value,
                                  EnumBronzeFields.DIAS_FUNCIONAMENTO.value,
                                  EnumBronzeFields.PAIS.value,
                                  EnumBronzeFields.NOME_SERVICOS_PRESTADOS.value,
                                  EnumBronzeFields.UF.value]

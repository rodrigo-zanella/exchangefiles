from platform import python_version

__python_version__ = python_version()
__name__ = 'opin_lib_canais_rede_referenciada_dados'
__title__ = 'OPIN - Rede Referenciada'
__description__ = 'Projeto de dados de Rede Referenciada do Open Insurance - Bradesco Seguros'
__version__ = '1.0.3'
__author__ = 'CI&T'
__python_requires__ = '>=3.8.5'